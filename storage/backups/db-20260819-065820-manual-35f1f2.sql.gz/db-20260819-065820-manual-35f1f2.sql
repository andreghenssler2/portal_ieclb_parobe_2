SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;


DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(180) DEFAULT NULL,
  `subtitulo` varchar(500) DEFAULT NULL,
  `imagem_id` bigint(20) unsigned NOT NULL,
  `url_link` varchar(500) DEFAULT NULL,
  `texto_botao` varchar(80) DEFAULT NULL,
  `nova_aba` tinyint(1) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `data_inicio` datetime DEFAULT NULL,
  `data_fim` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_banners_exibicao` (`ativo`,`data_inicio`,`data_fim`,`ordem`),
  KEY `idx_banners_imagem` (`imagem_id`),
  CONSTRAINT `fk_banners_imagem` FOREIGN KEY (`imagem_id`) REFERENCES `midias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `banners` (`id`,`titulo`,`subtitulo`,`imagem_id`,`url_link`,`texto_botao`,`nova_aba`,`ativo`,`ordem`,`data_inicio`,`data_fim`,`created_at`,`updated_at`) VALUES\n('1',NULL,NULL,'16',NULL,NULL,'0','0','10',NULL,NULL,'2026-08-18 21:13:52','2026-08-18 21:14:04');

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categorias` (`id`,`nome`,`slug`,`descricao`,`created_at`) VALUES\n('1','Notícias','noticias',NULL,'2026-08-18 19:29:06'),
('2','Cultos','cultos',NULL,'2026-08-18 19:29:06'),
('3','Eventos','eventos',NULL,'2026-08-18 19:29:06'),
('4','Juventude','juventude',NULL,'2026-08-18 19:29:06'),
('5','OASE','oase',NULL,'2026-08-18 19:29:06'),
('11','Comunidades','comunidades',NULL,'2026-08-18 19:56:44'),
('12','Entrepelado','entrepelado',NULL,'2026-08-19 06:53:05'),
('13','Parobé','parobe',NULL,'2026-08-19 06:53:09'),
('14','Fazenda Fialho','fazenda-fialho',NULL,'2026-08-19 06:53:24'),
('15','Passo dos Ferreiros','passo-dos-ferreiros',NULL,'2026-08-19 06:53:31'),
('16','Santa Cruz do Pinhal','santa-cruz-do-pinhal',NULL,'2026-08-19 06:53:38'),
('17','Missão Criança','missao-crianca',NULL,'2026-08-19 06:53:56'),
('18','Ação de Graças','acao-de-gracas',NULL,'2026-08-19 06:54:12'),
('19','KerbFest','kerbfest',NULL,'2026-08-19 06:54:25'),
('20','IECLB','ieclb',NULL,'2026-08-19 06:54:54'),
('21','Sinodo Nordeste Gaúcho','sinodo-nordeste-gaucho',NULL,'2026-08-19 06:55:02'),
('22','Informativo','informativo',NULL,'2026-08-19 06:55:29'),
('23','Meditação da Semana','meditac-ao-da-semana',NULL,'2026-08-19 06:55:39'),
('24','Paroquia','paroquia',NULL,'2026-08-19 06:55:49');

DROP TABLE IF EXISTS `comentarios`;
CREATE TABLE `comentarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `autor_nome` varchar(150) NOT NULL,
  `autor_email` varchar(190) NOT NULL,
  `conteudo` text NOT NULL,
  `status` enum('pendente','aprovado','spam','lixeira') NOT NULL DEFAULT 'pendente',
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `moderado_por` int(10) unsigned DEFAULT NULL,
  `moderado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_comentarios_post_status` (`post_id`,`status`,`created_at`),
  KEY `idx_comentarios_status_created` (`status`,`created_at`),
  KEY `fk_comentarios_moderador` (`moderado_por`),
  CONSTRAINT `fk_comentarios_moderador` FOREIGN KEY (`moderado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_comentarios_post` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `comunidades`;
CREATE TABLE `comunidades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `slug` varchar(160) NOT NULL,
  `descricao` text DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `cidade` varchar(120) DEFAULT NULL,
  `uf` char(2) DEFAULT NULL,
  `imagem` varchar(255) DEFAULT NULL,
  `ativa` tinyint(1) NOT NULL DEFAULT 1,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `comunidades` (`id`,`nome`,`slug`,`descricao`,`endereco`,`cidade`,`uf`,`imagem`,`ativa`,`ordem`,`created_at`,`updated_at`) VALUES\n('1','Parobé','parobe',NULL,NULL,'Parobé','RS',NULL,'1','1','2026-08-18 19:29:06','2026-08-18 19:29:06'),
('2','Entrepelado','entrepelado',NULL,NULL,'Taquara','RS',NULL,'1','2','2026-08-18 19:29:06','2026-08-18 19:29:06'),
('3','Fazenda Fialho','fazenda-fialho',NULL,NULL,'Taquara','RS',NULL,'1','3','2026-08-18 19:29:06','2026-08-18 19:29:06'),
('4','Santa Cruz do Pinhal','santa-cruz-do-pinhal',NULL,NULL,'Taquara','RS',NULL,'1','4','2026-08-18 19:29:06','2026-08-18 19:29:06'),
('5','Passo dos Ferreiros','passo-dos-ferreiros',NULL,NULL,'Parobé','RS',NULL,'1','5','2026-08-18 19:29:06','2026-08-18 19:29:06');

DROP TABLE IF EXISTS `configuracoes`;
CREATE TABLE `configuracoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chave` varchar(120) NOT NULL,
  `valor` longtext DEFAULT NULL,
  `tipo` varchar(30) NOT NULL DEFAULT 'texto',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `chave` (`chave`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `configuracoes` (`id`,`chave`,`valor`,`tipo`,`updated_at`) VALUES\n('1','site_nome','Paróquia Evangélica de Confissão Luterana de Parobé','texto','2026-08-18 19:29:06'),
('2','site_descricao','Portal da IECLB Parobé','texto','2026-08-18 19:29:06'),
('3','site_email','parobeieclb@gmail.com','email','2026-08-18 21:16:51'),
('4','site_telefone','5135431519','texto','2026-08-18 21:16:51'),
('5','site_endereco','Rua João Correa 201 Centro Parobe','texto','2026-08-18 21:16:51'),
('6','site_instagram','','url','2026-08-18 19:29:06'),
('7','site_youtube','','url','2026-08-18 19:29:06'),
('8','site_facebook','','url','2026-08-18 19:29:06'),
('9','site_logo_id','16','numero','2026-08-18 19:54:11'),
('10','site_favicon_id','17','numero','2026-08-18 19:54:11'),
('11','hero_titulo','IECLB Parobé','texto','2026-08-18 19:29:06'),
('12','hero_subtitulo','Notícias, cultos, eventos e informações das comunidades da Paróquia de Parobé.','texto','2026-08-18 19:29:06'),
('13','footer_texto','Paróquia Evangélica de Confissão Luterana de Parobé','texto','2026-08-18 19:29:06'),
('14','seo_titulo','IECLB Parobé','texto','2026-08-18 19:29:06'),
('15','seo_descricao','Portal da IECLB Parobé','texto','2026-08-18 19:29:06'),
('16','seo_keywords','IECLB, Parobé, igreja luterana, cultos, eventos','texto','2026-08-18 19:29:06'),
('17','seo_og_image_id','','numero','2026-08-18 19:29:06'),
('65','seo_title_separator','-','texto','2026-08-18 20:05:59'),
('66','seo_append_site_name','1','texto','2026-08-18 20:05:59'),
('67','seo_robots_index','1','texto','2026-08-18 20:05:59'),
('68','seo_robots_follow','1','texto','2026-08-18 20:05:59'),
('69','seo_social_title','','texto','2026-08-18 20:05:59'),
('71','seo_social_description','','texto','2026-08-18 20:05:59'),
('72','seo_open_graph_ativo','1','texto','2026-08-18 20:05:59'),
('73','seo_twitter_card_ativo','1','texto','2026-08-18 20:05:59'),
('74','seo_twitter_site','','texto','2026-08-18 20:05:59'),
('75','seo_sitemap_ativo','1','booleano','2026-08-18 20:06:55'),
('76','seo_sitemap_posts','1','booleano','2026-08-18 20:06:55'),
('77','seo_sitemap_paginas','1','booleano','2026-08-18 20:06:55'),
('78','seo_sitemap_eventos','0','booleano','2026-08-18 20:06:55'),
('79','seo_sitemap_galerias','1','booleano','2026-08-18 20:06:55'),
('80','seo_sitemap_formularios','0','booleano','2026-08-18 20:06:55'),
('81','seo_sitemap_ultima_geracao','2026-08-19 06:28:20','datahora','2026-08-19 06:28:20'),
('89','active_theme','classico','texto','2026-08-18 21:13:25'),
('90','aparencia_cor_primaria','#0b185b','texto','2026-08-18 20:44:01'),
('91','aparencia_cor_secundaria','#6c757d','texto','2026-08-18 20:30:46'),
('92','aparencia_cor_fundo','#ffffff','texto','2026-08-18 20:30:46'),
('93','aparencia_cor_texto','#1f2937','texto','2026-08-18 20:30:46'),
('94','aparencia_cor_rodape','#f8f9fa','texto','2026-08-18 20:30:46'),
('95','aparencia_cor_rodape_texto','#495057','texto','2026-08-18 20:30:46'),
('96','aparencia_container_max','1140','numero','2026-08-18 20:30:46'),
('97','aparencia_cabecalho_sticky','0','texto','2026-08-18 20:44:01'),
('98','aparencia_mostrar_nome_com_logo','0','texto','2026-08-18 20:44:01'),
('99','aparencia_bordas_arredondadas','16','numero','2026-08-18 20:30:46'),
('124','site_timezone','America/Sao_Paulo','texto','2026-08-18 20:51:06'),
('125','date_format','d/m/Y','texto','2026-08-18 20:51:06'),
('126','time_format','H:i','texto','2026-08-18 20:51:06'),
('127','writing_default_category','','texto','2026-08-18 20:51:35'),
('128','writing_default_status','publicado','texto','2026-08-18 20:51:35'),
('129','writing_excerpt_length','180','numero','2026-08-18 20:51:06'),
('130','reading_home_posts','9','numero','2026-08-18 20:51:06'),
('131','reading_home_events','6','numero','2026-08-18 20:51:06'),
('132','reading_home_galleries','3','numero','2026-08-18 20:51:06'),
('133','reading_home_communities','10','numero','2026-08-18 20:51:06'),
('134','media_upload_max_mb','10','numero','2026-08-18 20:51:06'),
('135','media_organize_year_month','1','booleano','2026-08-18 20:51:06'),
('136','media_allow_documents','1','booleano','2026-08-18 20:51:06'),
('137','media_delete_file_on_delete','1','booleano','2026-08-18 20:51:06'),
('138','permalink_noticia','noticia','texto','2026-08-18 20:51:06'),
('139','permalink_pagina','pagina','texto','2026-08-18 20:51:06'),
('140','permalink_evento','evento','texto','2026-08-18 20:51:06'),
('141','permalink_galeria','galeria','texto','2026-08-18 20:51:06'),
('142','permalink_formulario','formulario','texto','2026-08-18 20:51:06'),
('143','privacy_page_id','1','numero','2026-08-19 06:49:54'),
('144','privacy_footer_link','1','booleano','2026-08-18 20:51:06'),
('145','privacy_allow_search_engines','0','booleano','2026-08-18 20:58:27'),
('152','comments_enabled','0','booleano','2026-08-18 21:07:56'),
('153','comments_default_open','0','booleano','2026-08-18 21:07:56'),
('154','comments_require_moderation','0','booleano','2026-08-18 21:07:56'),
('155','comments_max_length','2000','numero','2026-08-18 21:07:45'),
('156','comments_rate_limit_seconds','60','numero','2026-08-18 21:07:45'),
('176','writing_revision_limit','30','numero','2026-08-18 21:17:49'),
('177','seo_sitemap_geral','1','booleano','2026-08-19 06:25:00'),
('178','seo_sitemap_tags','0','booleano','2026-08-19 06:28:20'),
('179','seo_sitemap_imagens','1','booleano','2026-08-19 06:25:00'),
('190','seo_feed_ativo','1','booleano','2026-08-19 06:31:54'),
('191','seo_feed_limite','20','numero','2026-08-19 06:31:54'),
('192','seo_feed_conteudo','resumo','texto','2026-08-19 06:31:54'),
('193','seo_feed_imagens','1','booleano','2026-08-19 06:31:54'),
('194','seo_feed_autor','1','booleano','2026-08-19 06:31:54'),
('195','seo_feed_eventos','0','booleano','2026-08-19 06:32:23'),
('196','seo_feed_categorias','1','booleano','2026-08-19 06:31:54'),
('197','seo_feed_tags','1','booleano','2026-08-19 06:31:54'),
('198','seo_sitemap_categorias','1','booleano','2026-08-19 06:31:54'),
('207','security_session_timeout_minutes','60','numero','2026-08-19 06:46:54'),
('208','security_max_login_attempts','5','numero','2026-08-19 06:46:54'),
('209','security_lockout_minutes','15','numero','2026-08-19 06:46:54'),
('210','security_audit_retention_days','180','numero','2026-08-19 06:46:54'),
('211','security_log_failed_logins','1','booleano','2026-08-19 06:46:54'),
('215','backup_retention_count','10','numero','2026-08-19 06:57:23'),
('216','maintenance_enabled','0','booleano','2026-08-19 06:57:23'),
('217','maintenance_title','Portal temporariamente em manutenção','texto','2026-08-19 06:57:23'),
('218','maintenance_message','Estamos realizando melhorias. Tente novamente em alguns instantes.','texto','2026-08-19 06:57:23'),
('219','maintenance_expected_end','','texto','2026-08-19 06:57:23'),
('220','maintenance_allow_admins','1','booleano','2026-08-19 06:57:23'),
('221','maintenance_allowed_ips','','texto','2026-08-19 06:57:23'),
('222','maintenance_enabled_at','','texto','2026-08-19 06:57:23'),
('223','tools_theme_backup_retention_days','90','numero','2026-08-19 06:57:23');

DROP TABLE IF EXISTS `evento_categorias`;
CREATE TABLE `evento_categorias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ativa` tinyint(1) NOT NULL DEFAULT 1,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_evento_categorias_ativa_ordem` (`ativa`,`ordem`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `evento_categorias` (`id`,`nome`,`slug`,`descricao`,`ativa`,`ordem`,`created_at`,`updated_at`) VALUES\n('1','Juventude','juventude','Encontros, ações e atividades da juventude.','1','10','2026-08-18 20:56:33','2026-08-18 20:56:33'),
('2','Crianças','criancas','Atividades, cultos e encontros com crianças.','1','20','2026-08-18 20:56:33','2026-08-18 20:56:33'),
('3','Famílias','familias','Encontros e atividades voltadas às famílias.','1','30','2026-08-18 20:56:33','2026-08-18 20:56:33'),
('4','Formação','formacao','Cursos, estudos, palestras e momentos formativos.','1','40','2026-08-18 20:56:33','2026-08-18 20:56:33'),
('5','Reuniões','reunioes','Reuniões de grupos, lideranças e conselhos.','1','50','2026-08-18 20:56:33','2026-08-18 20:56:33'),
('6','Festas e confraternizações','festas-e-confraternizacoes','Festas, almoços e momentos de convivência.','1','60','2026-08-18 20:56:33','2026-08-18 20:56:33'),
('7','Ação Social','acao-social','Campanhas, arrecadações e ações solidárias.','1','70','2026-08-18 20:56:33','2026-08-18 20:56:33');

DROP TABLE IF EXISTS `eventos`;
CREATE TABLE `eventos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `comunidade_id` int(10) unsigned DEFAULT NULL,
  `categoria_evento_id` int(10) unsigned DEFAULT NULL,
  `tipo` enum('culto','evento') NOT NULL DEFAULT 'evento',
  `titulo` varchar(220) NOT NULL,
  `slug` varchar(240) NOT NULL,
  `resumo` text DEFAULT NULL,
  `descricao` longtext DEFAULT NULL,
  `local` varchar(255) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `data_inicio` datetime NOT NULL,
  `data_fim` datetime DEFAULT NULL,
  `santa_ceia` tinyint(1) NOT NULL DEFAULT 0,
  `imagem_capa_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('rascunho','publicado','cancelado','arquivado') NOT NULL DEFAULT 'rascunho',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `seo_titulo` varchar(180) DEFAULT NULL,
  `seo_descricao` varchar(320) DEFAULT NULL,
  `seo_noindex` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_eventos_autor` (`autor_id`),
  KEY `idx_eventos_status_data` (`status`,`data_inicio`),
  KEY `idx_eventos_tipo_data` (`tipo`,`data_inicio`),
  KEY `idx_eventos_comunidade` (`comunidade_id`),
  KEY `idx_eventos_imagem_capa` (`imagem_capa_id`),
  KEY `idx_eventos_categoria` (`categoria_evento_id`),
  CONSTRAINT `fk_eventos_autor` FOREIGN KEY (`autor_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `fk_eventos_categoria` FOREIGN KEY (`categoria_evento_id`) REFERENCES `evento_categorias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_eventos_comunidade` FOREIGN KEY (`comunidade_id`) REFERENCES `comunidades` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_eventos_imagem_capa` FOREIGN KEY (`imagem_capa_id`) REFERENCES `midias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `eventos` (`id`,`autor_id`,`comunidade_id`,`categoria_evento_id`,`tipo`,`titulo`,`slug`,`resumo`,`descricao`,`local`,`endereco`,`data_inicio`,`data_fim`,`santa_ceia`,`imagem_capa_id`,`status`,`created_at`,`updated_at`,`seo_titulo`,`seo_descricao`,`seo_noindex`) VALUES\n('1','1',NULL,NULL,'culto','Missão Criança 2026','miss-ao-crianca-2026-2026-08-23',NULL,NULL,'Igreja de Parobe',NULL,'2026-08-23 09:00:00','2026-08-23 10:30:00','0','18','publicado','2026-08-18 21:03:39','2026-08-18 21:03:55',NULL,NULL,'0'),
('2','1','1','7','evento','Assistência Social','assist-encia-social-2026-08-24',NULL,NULL,'Centro Comunitario',NULL,'2026-08-24 13:30:00','2026-08-24 15:00:00','0',NULL,'publicado','2026-08-19 06:23:51','2026-08-19 06:23:51',NULL,NULL,'1');

DROP TABLE IF EXISTS `formulario_campos`;
CREATE TABLE `formulario_campos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `formulario_id` int(10) unsigned NOT NULL,
  `tipo` enum('texto','email','telefone','numero','data','textarea','select','checkbox') NOT NULL DEFAULT 'texto',
  `rotulo` varchar(180) NOT NULL,
  `nome` varchar(120) NOT NULL,
  `placeholder` varchar(255) DEFAULT NULL,
  `opcoes` text DEFAULT NULL,
  `obrigatorio` tinyint(1) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_formulario_campo_nome` (`formulario_id`,`nome`),
  KEY `idx_formulario_campos_ordem` (`formulario_id`,`ativo`,`ordem`),
  CONSTRAINT `fk_formulario_campos_formulario` FOREIGN KEY (`formulario_id`) REFERENCES `formularios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `formulario_campos` (`id`,`formulario_id`,`tipo`,`rotulo`,`nome`,`placeholder`,`opcoes`,`obrigatorio`,`ativo`,`ordem`,`created_at`,`updated_at`) VALUES\n('1','1','texto','Nome','nome','Seu nome completo',NULL,'1','1','10','2026-08-18 19:47:38','2026-08-18 19:47:38'),
('2','1','email','E-mail','email','seu@email.com',NULL,'1','1','20','2026-08-18 19:47:38','2026-08-18 19:47:38'),
('3','1','telefone','Telefone','telefone','(51) 99999-9999',NULL,'0','1','30','2026-08-18 19:47:38','2026-08-18 19:47:38'),
('4','1','texto','Assunto','assunto','Assunto da mensagem',NULL,'1','1','40','2026-08-18 19:47:38','2026-08-18 19:47:38'),
('5','1','textarea','Mensagem','mensagem','Escreva sua mensagem',NULL,'1','1','50','2026-08-18 19:47:38','2026-08-18 19:47:38');

DROP TABLE IF EXISTS `formulario_resposta_valores`;
CREATE TABLE `formulario_resposta_valores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `resposta_id` bigint(20) unsigned NOT NULL,
  `campo_id` bigint(20) unsigned NOT NULL,
  `valor` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_resposta_campo` (`resposta_id`,`campo_id`),
  KEY `idx_form_resp_val_campo` (`campo_id`),
  CONSTRAINT `fk_form_resp_val_campo` FOREIGN KEY (`campo_id`) REFERENCES `formulario_campos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_form_resp_val_resposta` FOREIGN KEY (`resposta_id`) REFERENCES `formulario_respostas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `formulario_respostas`;
CREATE TABLE `formulario_respostas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `formulario_id` int(10) unsigned NOT NULL,
  `status` enum('nova','lida','arquivada') NOT NULL DEFAULT 'nova',
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `origem` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_formulario_respostas_status` (`formulario_id`,`status`,`created_at`),
  CONSTRAINT `fk_formulario_respostas_formulario` FOREIGN KEY (`formulario_id`) REFERENCES `formularios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `formularios`;
CREATE TABLE `formularios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `titulo` varchar(220) NOT NULL,
  `slug` varchar(240) NOT NULL,
  `descricao` text DEFAULT NULL,
  `mensagem_sucesso` varchar(500) DEFAULT NULL,
  `status` enum('rascunho','publicado','arquivado') NOT NULL DEFAULT 'rascunho',
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `publicado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_formularios_autor` (`autor_id`),
  KEY `idx_formularios_status` (`status`,`ativo`,`publicado_em`),
  CONSTRAINT `fk_formularios_autor` FOREIGN KEY (`autor_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `formularios` (`id`,`autor_id`,`titulo`,`slug`,`descricao`,`mensagem_sucesso`,`status`,`ativo`,`publicado_em`,`created_at`,`updated_at`) VALUES\n('1','1','Contato','contato','Entre em contato com a Paróquia Evangélica de Confissão Luterana de Parobé.','Sua mensagem foi enviada com sucesso. Agradecemos o contato!','publicado','1','2026-08-18 19:47:38','2026-08-18 19:47:38','2026-08-18 19:47:38');

DROP TABLE IF EXISTS `galeria_midias`;
CREATE TABLE `galeria_midias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `galeria_id` int(10) unsigned NOT NULL,
  `midia_id` bigint(20) unsigned NOT NULL,
  `legenda` varchar(255) DEFAULT NULL,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_galeria_midia` (`galeria_id`,`midia_id`),
  KEY `idx_galeria_midias_ordem` (`galeria_id`,`ordem`),
  KEY `idx_galeria_midias_midia` (`midia_id`),
  CONSTRAINT `fk_galeria_midias_galeria` FOREIGN KEY (`galeria_id`) REFERENCES `galerias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_galeria_midias_midia` FOREIGN KEY (`midia_id`) REFERENCES `midias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `galerias`;
CREATE TABLE `galerias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `titulo` varchar(220) NOT NULL,
  `slug` varchar(240) NOT NULL,
  `descricao` text DEFAULT NULL,
  `imagem_capa_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('rascunho','publicado','arquivado') NOT NULL DEFAULT 'rascunho',
  `publicado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `seo_titulo` varchar(180) DEFAULT NULL,
  `seo_descricao` varchar(320) DEFAULT NULL,
  `seo_noindex` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_galerias_autor` (`autor_id`),
  KEY `idx_galerias_status_data` (`status`,`publicado_em`),
  KEY `idx_galerias_capa` (`imagem_capa_id`),
  CONSTRAINT `fk_galerias_autor` FOREIGN KEY (`autor_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `fk_galerias_capa` FOREIGN KEY (`imagem_capa_id`) REFERENCES `midias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `login_tentativas`;
CREATE TABLE `login_tentativas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(190) NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `sucesso` tinyint(1) NOT NULL DEFAULT 0,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_login_tentativas_email_data` (`email`,`created_at`),
  KEY `idx_login_tentativas_ip_data` (`ip`,`created_at`),
  KEY `idx_login_tentativas_sucesso_data` (`sucesso`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned DEFAULT NULL,
  `acao` varchar(120) NOT NULL,
  `entidade` varchar(100) DEFAULT NULL,
  `entidade_id` bigint(20) unsigned DEFAULT NULL,
  `detalhes` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `nivel` varchar(20) NOT NULL DEFAULT 'info',
  `metodo` varchar(10) DEFAULT NULL,
  `rota` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `request_id` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_logs_created` (`created_at`),
  KEY `idx_logs_usuario` (`usuario_id`),
  KEY `idx_logs_entidade` (`entidade`,`entidade_id`),
  KEY `idx_logs_nivel_created` (`nivel`,`created_at`),
  KEY `idx_logs_usuario_created` (`usuario_id`,`created_at`),
  KEY `idx_logs_acao_created` (`acao`,`created_at`),
  CONSTRAINT `fk_logs_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `logs` (`id`,`usuario_id`,`acao`,`entidade`,`entidade_id`,`detalhes`,`ip`,`nivel`,`metodo`,`rota`,`user_agent`,`request_id`,`created_at`) VALUES\n('1','1','menu_item.criar','menu_itens','4','Eventos','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:34:21'),
('2','1','midia.upload','midias','1','8ae15a06-3cb9-4c9a-ae30-02d55dade895.png','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('3','1','midia.upload','midias','2','8ff448e7-33f8-46db-aa53-b077574855ca.png','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('4','1','midia.upload','midias','3','2300c6e2-bc22-4e6a-9a3f-fbf5ac850f0f.png','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('5','1','midia.upload','midias','4','30966f04-b4c7-47ab-a3d3-030df400fa1b.png','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('6','1','midia.upload','midias','5','6905346a-dee7-4015-b0d4-6b137b4c7431.png','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('7','1','midia.upload','midias','6','20221022_080859-EDIT.jpg','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('8','1','midia.upload','midias','7','ced785d5-6f71-4bf2-b909-e8102a24fec6.png','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('9','1','midia.upload','midias','8','entrepelado 2.jpeg','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('10','1','midia.upload','midias','9','Entrepelado.jpg','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('11','1','midia.upload','midias','10','Faz. Fialho.jpg','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('12','1','midia.upload','midias','11','FB_IMG_1743371201573.jpg','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('13','1','midia.upload','midias','12','Parobe.jpg','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('14','1','midia.upload','midias','13','Passo dos Ferreiros.jpg','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('15','1','midia.upload','midias','14','Santa Cruz.jpg','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:37:09'),
('16','1','noticia.criar','posts','1','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:50:49'),
('17','1','midia.upload','midias','15','Imagem destacada de notícia','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:51:48'),
('18','1','noticia.editar','posts','1','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:51:48'),
('19','1','midia.upload','midias','16','Imagem enviada pelas configurações do portal','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:54:11'),
('20','1','midia.upload','midias','17','Imagem enviada pelas configurações do portal','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:54:11'),
('21','1','configuracoes.atualizar','configuracoes',NULL,'Configurações gerais e SEO atualizadas','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:54:11'),
('22','1','categoria.criar','categorias','11','Comunidades','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 19:56:44'),
('23','1','seo.sitemap.atualizar','configuracoes',NULL,'Configurações de Sitemap atualizadas','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:06:55'),
('24','1','noticia.editar','posts','1','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:18:36'),
('25','1','aparencia.tema_ativar','tema',NULL,'Tema ativado: classico','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:31:18'),
('26','1','aparencia.tema_ativar','tema',NULL,'Tema ativado: ieclb','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:42:51'),
('27','1','aparencia.personalizar','configuracoes',NULL,'Personalização visual atualizada','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:44:01'),
('28','1','aparencia.personalizar','configuracoes',NULL,'Personalização visual atualizada','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:44:02'),
('29','1','aparencia.tema_ativar','tema',NULL,'Tema ativado: classico','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:46:13'),
('30','1','aparencia.tema_ativar','tema',NULL,'Tema ativado: ieclb','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:46:34'),
('31','1','configuracoes.escrita','configuracoes',NULL,NULL,'::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:51:35'),
('32','1','menu.criar','menus','5','Menu_1','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:55:47'),
('33','1','configuracoes.privacidade','configuracoes',NULL,NULL,'::1','info',NULL,NULL,NULL,NULL,'2026-08-18 20:58:27'),
('34','1','midia.upload','midias','18','Imagem destacada de evento/culto','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:03:39'),
('35','1','agenda.criar','eventos','1','culto: Missão Criança 2026','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:03:39'),
('36','1','agenda.editar','eventos','1','culto: Missão Criança 2026','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:03:55'),
('37','1','configuracoes.discussao','configuracoes',NULL,NULL,'::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:07:56'),
('38','1','noticia.editar','posts','1','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:08:42'),
('39','1','midia.upload','midias','19','Imagem destacada de notícia','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:10:44'),
('40','1','noticia.criar','posts','2','IECLB Parobé realizou o culto de instalação da Nova Diretoria da Paroquia','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:10:44'),
('41','1','aparencia.tema_ativar','tema',NULL,'Tema ativado: classico','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:13:25'),
('42','1','banner.salvar','banners','1','Banner','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:13:52'),
('43','1','banner.alternar','banners','1',NULL,'::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:14:04'),
('44','1','menu_item.criar','menu_itens','7','Oferta','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:15:04'),
('45','1','configuracoes.geral','configuracoes',NULL,'Configurações gerais atualizadas','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:16:51'),
('46','1','noticia.editar','posts','1','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:18:44'),
('47','1','noticia.editar','posts','1','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','::1','info',NULL,NULL,NULL,NULL,'2026-08-18 21:18:53'),
('48','1','agenda.criar','eventos','2','evento: Assistência Social','::1','info',NULL,NULL,NULL,NULL,'2026-08-19 06:23:51'),
('49','1','seo.sitemap.atualizar','configuracoes',NULL,'Configurações do índice e sub-sitemaps atualizadas','::1','info',NULL,NULL,NULL,NULL,'2026-08-19 06:28:20'),
('50','1','seo.feeds.atualizar','configuracoes',NULL,'Configurações de feeds RSS atualizadas','::1','info',NULL,NULL,NULL,NULL,'2026-08-19 06:32:23'),
('51','1','widgets.atualizar','widgets',NULL,'Widgets da Home atualizados','::1','info',NULL,NULL,NULL,NULL,'2026-08-19 06:38:45'),
('52','1','widgets.atualizar','widgets',NULL,'Widgets da Home atualizados','::1','info',NULL,NULL,NULL,NULL,'2026-08-19 06:38:59'),
('53','1','midia.upload','midias','20','Upload pelo editor de conteúdo','::1','info',NULL,NULL,NULL,NULL,'2026-08-19 06:45:09'),
('54','1','noticia.criar','posts','3','EU NÃO… TÔ FORA!','::1','info',NULL,NULL,NULL,NULL,'2026-08-19 06:45:39'),
('55','1','pagina.criar','paginas','1','Política de Privacidade','::1','info','POST','/portal_ieclb_parobe/admin/paginas/form.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','6e84f6df2a388cae','2026-08-19 06:49:44'),
('56','1','configuracoes.privacidade','configuracoes',NULL,NULL,'::1','info','POST','/portal_ieclb_parobe/admin/configuracoes/privacidade.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','772372a7d9f9f46a','2026-08-19 06:49:54'),
('57','1','pagina.editar','paginas','1','Política de Privacidade','::1','info','POST','/portal_ieclb_parobe/admin/paginas/form.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','df7c667f1d554210','2026-08-19 06:50:30'),
('58','1','categoria.criar','categorias','12','Entrepelado','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','045d6f0ce08186d7','2026-08-19 06:53:05'),
('59','1','categoria.criar','categorias','13','Parobé','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','a9e330749f9bed3d','2026-08-19 06:53:09'),
('60','1','categoria.criar','categorias','14','Fazenda Fialho','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','b489d0cb815e3a87','2026-08-19 06:53:24'),
('61','1','categoria.criar','categorias','15','Passo dos Ferreiros','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','c9433d049440271a','2026-08-19 06:53:31'),
('62','1','categoria.criar','categorias','16','Santa Cruz do Pinhal','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','6e97dfe2f275b920','2026-08-19 06:53:38'),
('63','1','categoria.criar','categorias','17','Missão Criança','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','362e1e61bdbb94fd','2026-08-19 06:53:56'),
('64','1','categoria.editar','categorias','17','Missão Criança','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','27eb006b45d1f133','2026-08-19 06:54:01'),
('65','1','categoria.criar','categorias','18','Ação de Graças','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','22f171804c8ce401','2026-08-19 06:54:12'),
('66','1','categoria.criar','categorias','19','KerbFest','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','15102aabf451a368','2026-08-19 06:54:25'),
('67','1','categoria.criar','categorias','20','IECLB','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','65f9e592d6704180','2026-08-19 06:54:54'),
('68','1','categoria.criar','categorias','21','Sinodo Nordeste Gaucho','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','3c783084bbf4bd32','2026-08-19 06:55:02'),
('69','1','categoria.editar','categorias','21','Sinodo Nordeste Gaúcho','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','faf6cc0c8c688ea4','2026-08-19 06:55:08'),
('70','1','categoria.editar','categorias','18','Ação de Graças','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2eb755d874129cc7','2026-08-19 06:55:19'),
('71','1','categoria.criar','categorias','22','Informativo','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','4f1b48192579f2f8','2026-08-19 06:55:29'),
('72','1','categoria.criar','categorias','23','Meditação da Semana','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','b90644354effe8ea','2026-08-19 06:55:39'),
('73','1','categoria.criar','categorias','24','Paroquia','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','cca3f590f5b4b60b','2026-08-19 06:55:49'),
('74','1','categoria.editar','categorias','13','Parobé','::1','info','POST','/portal_ieclb_parobe/admin/categorias/index.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','70875078318beeb1','2026-08-19 06:56:05'),
('75','1','noticia.editar','posts','2','IECLB Parobé realizou o culto de instalação da Nova Diretoria da Paroquia','::1','info','POST','/portal_ieclb_parobe/admin/noticias/form.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','27e53dbdef79aa94','2026-08-19 06:56:29'),
('76','1','noticia.editar','posts','1','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','::1','info','POST','/portal_ieclb_parobe/admin/noticias/form.php','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','b6cd85665ffcb4fe','2026-08-19 06:56:46');

DROP TABLE IF EXISTS `menu_itens`;
CREATE TABLE `menu_itens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `tipo` enum('link','pagina') NOT NULL DEFAULT 'link',
  `titulo` varchar(160) NOT NULL,
  `url` varchar(500) DEFAULT NULL,
  `nova_aba` tinyint(1) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_menu_itens_menu_ordem` (`menu_id`,`ordem`),
  KEY `idx_menu_itens_parent` (`parent_id`),
  KEY `idx_menu_itens_pagina` (`pagina_id`),
  CONSTRAINT `fk_menu_itens_menu` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_menu_itens_pagina` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_menu_itens_parent` FOREIGN KEY (`parent_id`) REFERENCES `menu_itens` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `menu_itens` (`id`,`menu_id`,`parent_id`,`pagina_id`,`tipo`,`titulo`,`url`,`nova_aba`,`ativo`,`ordem`,`created_at`,`updated_at`) VALUES\n('1','1',NULL,NULL,'link','Início','/','0','1','10','2026-08-18 19:29:07','2026-08-18 19:29:07'),
('2','1',NULL,NULL,'link','Agenda','agenda.php','0','1','20','2026-08-18 19:29:07','2026-08-18 19:29:07'),
('3','1',NULL,NULL,'link','Comunidades','comunidades.php','0','1','30','2026-08-18 19:29:07','2026-08-18 19:29:07'),
('4','1','1',NULL,'link','Eventos','/','0','1','0','2026-08-18 19:34:21','2026-08-18 19:34:21'),
('5','1',NULL,NULL,'link','Galerias','galerias.php','0','1','40','2026-08-18 19:42:49','2026-08-18 19:42:49'),
('6','1',NULL,NULL,'link','Contato','formulario/contato','0','1','50','2026-08-18 19:47:38','2026-08-18 19:47:38'),
('7','5',NULL,NULL,'link','Oferta','https://checkout.ieclbparobe.com.br/','0','1','0','2026-08-18 21:15:04','2026-08-18 21:15:04');

DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `localizacao` varchar(80) NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `localizacao` (`localizacao`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `menus` (`id`,`nome`,`slug`,`localizacao`,`ativo`,`created_at`,`updated_at`) VALUES\n('1','Menu Principal','menu-principal','principal','1','2026-08-18 19:29:07','2026-08-18 19:29:07'),
('5','Menu_1','menu-1','rodape','1','2026-08-18 20:55:47','2026-08-18 20:55:47');

DROP TABLE IF EXISTS `midias`;
CREATE TABLE `midias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned DEFAULT NULL,
  `nome_original` varchar(255) NOT NULL,
  `nome_arquivo` varchar(255) NOT NULL,
  `caminho` varchar(500) NOT NULL,
  `mime_type` varchar(150) NOT NULL,
  `extensao` varchar(20) NOT NULL,
  `tamanho` bigint(20) unsigned NOT NULL DEFAULT 0,
  `largura` int(10) unsigned DEFAULT NULL,
  `altura` int(10) unsigned DEFAULT NULL,
  `titulo` varchar(180) DEFAULT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `caminho` (`caminho`),
  KEY `fk_midias_usuario` (`usuario_id`),
  KEY `idx_midias_mime` (`mime_type`),
  KEY `idx_midias_created` (`created_at`),
  CONSTRAINT `fk_midias_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `midias` (`id`,`usuario_id`,`nome_original`,`nome_arquivo`,`caminho`,`mime_type`,`extensao`,`tamanho`,`largura`,`altura`,`titulo`,`alt_text`,`created_at`,`updated_at`) VALUES\n('1','1','8ae15a06-3cb9-4c9a-ae30-02d55dade895.png','96b7ef0320147b9a16fcd08ecb4d99ed4b0f.png','uploads/2026/08/96b7ef0320147b9a16fcd08ecb4d99ed4b0f.png','image/png','png','2546653','1024','1536','8ae15a06-3cb9-4c9a-ae30-02d55dade895',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('2','1','8ff448e7-33f8-46db-aa53-b077574855ca.png','ecd8edb6aa52315b205ec4ffe81ce0bc169b.png','uploads/2026/08/ecd8edb6aa52315b205ec4ffe81ce0bc169b.png','image/png','png','2903251','1024','1536','8ff448e7-33f8-46db-aa53-b077574855ca',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('3','1','2300c6e2-bc22-4e6a-9a3f-fbf5ac850f0f.png','e8af271b758f541bb469964a931a402d0748.png','uploads/2026/08/e8af271b758f541bb469964a931a402d0748.png','image/png','png','2489888','1024','1536','2300c6e2-bc22-4e6a-9a3f-fbf5ac850f0f',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('4','1','30966f04-b4c7-47ab-a3d3-030df400fa1b.png','edeb1f275c6053831e1d4aabc1dd0b5b5407.png','uploads/2026/08/edeb1f275c6053831e1d4aabc1dd0b5b5407.png','image/png','png','2359858','1024','1536','30966f04-b4c7-47ab-a3d3-030df400fa1b',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('5','1','6905346a-dee7-4015-b0d4-6b137b4c7431.png','e2d46fa820ecfda8dc02cbd9c76aa91ab3d4.png','uploads/2026/08/e2d46fa820ecfda8dc02cbd9c76aa91ab3d4.png','image/png','png','2652195','1536','1024','6905346a-dee7-4015-b0d4-6b137b4c7431',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('6','1','20221022_080859-EDIT.jpg','4c8b3436415b40c520cd23c877d5c56be179.jpg','uploads/2026/08/4c8b3436415b40c520cd23c877d5c56be179.jpg','image/jpeg','jpg','105980','724','633','20221022_080859-EDIT',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('7','1','ced785d5-6f71-4bf2-b909-e8102a24fec6.png','33f30cf412183c8f2823ea472fafcb6780a8.png','uploads/2026/08/33f30cf412183c8f2823ea472fafcb6780a8.png','image/png','png','3373408','1024','1536','ced785d5-6f71-4bf2-b909-e8102a24fec6',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('8','1','entrepelado 2.jpeg','e2634a17e38c32c150e06d96a853a9ec5174.jpg','uploads/2026/08/e2634a17e38c32c150e06d96a853a9ec5174.jpg','image/jpeg','jpg','219498','1200','1600','entrepelado 2',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('9','1','Entrepelado.jpg','c9c47d4351cf196f8ebb0eaabbeb49f74e4e.jpg','uploads/2026/08/c9c47d4351cf196f8ebb0eaabbeb49f74e4e.jpg','image/jpeg','jpg','135014','550','479','Entrepelado',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('10','1','Faz. Fialho.jpg','10462be87d1846f7c653413536862bb060be.jpg','uploads/2026/08/10462be87d1846f7c653413536862bb060be.jpg','image/jpeg','jpg','62796','382','510','Faz. Fialho',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('11','1','FB_IMG_1743371201573.jpg','747380ee32ed341bfa62afe8a07b0a39c072.jpg','uploads/2026/08/747380ee32ed341bfa62afe8a07b0a39c072.jpg','image/jpeg','jpg','124702','1080','1440','FB_IMG_1743371201573',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('12','1','Parobe.jpg','7bfece842df8d5ec715915e1245ca22ff825.jpg','uploads/2026/08/7bfece842df8d5ec715915e1245ca22ff825.jpg','image/jpeg','jpg','86107','383','633','Parobe',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('13','1','Passo dos Ferreiros.jpg','6e5ababc88df0a733e29424965c546f11aa9.jpg','uploads/2026/08/6e5ababc88df0a733e29424965c546f11aa9.jpg','image/jpeg','jpg','96877','512','325','Passo dos Ferreiros',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('14','1','Santa Cruz.jpg','841c01387be346e0fad0fdbfa7bc71aa2bf2.jpg','uploads/2026/08/841c01387be346e0fad0fdbfa7bc71aa2bf2.jpg','image/jpeg','jpg','98591','720','960','Santa Cruz',NULL,'2026-08-18 19:37:09','2026-08-18 19:37:09'),
('15','1','big_a1429bfa06218d8d0d64e286c889fbc9.jpg','187791a15a03ca0ce15704bb37991876654d.jpg','uploads/2026/08/187791a15a03ca0ce15704bb37991876654d.jpg','image/jpeg','jpg','45987','400','300','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','2026-08-18 19:51:48','2026-08-18 19:51:48'),
('16','1','cropped-portal-ieclb-parobe1-2-1.png','ef147b887579d3835e37714e5681eba51dd2.png','uploads/2026/08/ef147b887579d3835e37714e5681eba51dd2.png','image/png','png','78971','1400','250','cropped-portal-ieclb-parobe1-2-1',NULL,'2026-08-18 19:54:11','2026-08-18 19:54:11'),
('17','1','imagem-paroquia.png','3574ce16ec84b58334523467e124ec461ff0.png','uploads/2026/08/3574ce16ec84b58334523467e124ec461ff0.png','image/png','png','651542','907','901','imagem-paroquia',NULL,'2026-08-18 19:54:11','2026-08-18 19:54:11'),
('18','1','f3645bd5-340b-41f5-8ef9-54cf717e5749.png','61b573c0832a437fe433159fbf6b351a2f39.png','uploads/2026/08/61b573c0832a437fe433159fbf6b351a2f39.png','image/png','png','2187712','1448','1086','Missão Criança 2026','Missão Criança 2026','2026-08-18 21:03:39','2026-08-18 21:03:39'),
('19','1','IECLB-Parobe-realizou-o-culto-de-instalacao-da-Nova-Diretoria-da-Paroquia.jpg','27d04a305fe01725c7b2e1ab56fad2b3e186.jpg','uploads/2026/08/27d04a305fe01725c7b2e1ab56fad2b3e186.jpg','image/jpeg','jpg','51206','720','323','IECLB Parobé realizou o culto de instalação da Nova Diretoria da Paroquia','IECLB Parobé realizou o culto de instalação da Nova Diretoria da Paroquia','2026-08-18 21:10:44','2026-08-18 21:10:44'),
('20','1','big_c52a67c2fc9b087055d4fee947b2f561.png','df668c337100f1faa6dfa85f308c8ee71af3.png','uploads/2026/08/df668c337100f1faa6dfa85f308c8ee71af3.png','image/png','png','32092','312','380','big_c52a67c2fc9b087055d4fee947b2f561',NULL,'2026-08-19 06:45:09','2026-08-19 06:45:09');

DROP TABLE IF EXISTS `paginas`;
CREATE TABLE `paginas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `titulo` varchar(220) NOT NULL,
  `slug` varchar(240) NOT NULL,
  `resumo` text DEFAULT NULL,
  `conteudo` longtext NOT NULL,
  `imagem_capa_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('rascunho','agendado','publicado','arquivado','lixeira') NOT NULL DEFAULT 'rascunho',
  `status_anterior` varchar(20) DEFAULT NULL,
  `lixeira_em` datetime DEFAULT NULL,
  `exibir_menu` tinyint(1) NOT NULL DEFAULT 0,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `publicado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `seo_titulo` varchar(180) DEFAULT NULL,
  `seo_descricao` varchar(320) DEFAULT NULL,
  `seo_noindex` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_paginas_autor` (`autor_id`),
  KEY `idx_paginas_status_data` (`status`,`publicado_em`),
  KEY `idx_paginas_menu` (`exibir_menu`,`ordem`),
  KEY `idx_paginas_imagem_capa` (`imagem_capa_id`),
  CONSTRAINT `fk_paginas_autor` FOREIGN KEY (`autor_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `fk_paginas_imagem_capa` FOREIGN KEY (`imagem_capa_id`) REFERENCES `midias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `paginas` (`id`,`autor_id`,`titulo`,`slug`,`resumo`,`conteudo`,`imagem_capa_id`,`status`,`status_anterior`,`lixeira_em`,`exibir_menu`,`ordem`,`publicado_em`,`created_at`,`updated_at`,`seo_titulo`,`seo_descricao`,`seo_noindex`) VALUES\n('1','1','Política de Privacidade','politica-de-privacidade',NULL,'<div class=\"block-title\">\r\n<h2 class=\"wp-block-heading\"><strong>1. Quais os tipos de informa&ccedil;&atilde;o coletamos</strong></h2>\r\n</div>\r\n<p class=\"wp-block-paragraph\">N&oacute;s recebemos, coletamos e arquivamos as informa&ccedil;&otilde;es que voc&ecirc; adiciona em nosso site ou nos fornece de qualquer outra forma. Al&eacute;m disso, n&oacute;s coletamos o endere&ccedil;o IP utilizado para conectar o seu computador &agrave; Internet; dados de login; endere&ccedil;o de e-mail; senha; informa&ccedil;&otilde;es do computador e internet e hist&oacute;rico de compra. N&oacute;s poderemos utilizar ferramentas para medir e coletar informa&ccedil;&otilde;es de navega&ccedil;&atilde;o, incluindo o tempo de resposta das p&aacute;ginas, tempo total da visita em determinadas p&aacute;ginas, informa&ccedil;&otilde;es de intera&ccedil;&atilde;o com p&aacute;gina e os m&eacute;todos utilizados para deixar a p&aacute;gina. N&oacute;s tamb&eacute;m coletamos informa&ccedil;&otilde;es de identifica&ccedil;&atilde;o pessoal (incluindo nome, e-mail, senha, meios de comunica&ccedil;&atilde;o); coment&aacute;rios, feedback, recomenda&ccedil;&otilde;es e perfil pessoal.&nbsp;</p>\r\n<p class=\"wp-block-paragraph\">​</p>\r\n<div class=\"block-title\">\r\n<h2 class=\"wp-block-heading\"><strong>2. Como coletamos essas informa&ccedil;&otilde;es</strong></h2>\r\n</div>\r\n<p class=\"wp-block-paragraph\">Quando voc&ecirc; realiza uma opera&ccedil;&atilde;o em nosso site, como parte do procedimento, n&oacute;s coletamos as informa&ccedil;&otilde;es pessoais fornecidas como o seu nome, endere&ccedil;o e endere&ccedil;o de e-mail. As suas informa&ccedil;&otilde;es pessoais ser&atilde;o utilizadas apenas para as a&ccedil;&otilde;es espec&iacute;ficas citadas abaixo.</p>\r\n<p class=\"wp-block-paragraph\">​</p>\r\n<div class=\"block-title\">\r\n<h2 class=\"wp-block-heading\"><strong>3. Por que coletamos essas informa&ccedil;&otilde;es pessoais</strong></h2>\r\n</div>\r\n<p class=\"wp-block-paragraph\">&ndash; Para prestar aos nossos usu&aacute;rios assist&ecirc;ncia e suporte t&eacute;cnico cont&iacute;nuos ao cliente;</p>\r\n<p class=\"wp-block-paragraph\">&ndash; Para prestar e operar os Servi&ccedil;os;</p>\r\n<p class=\"wp-block-paragraph\">&ndash; Para fornecer aos nossos usu&aacute;rios assist&ecirc;ncia ao cliente cont&iacute;nua e suporte t&eacute;cnico;</p>\r\n<p class=\"wp-block-paragraph\">&ndash; Para poder entrar em contato com nossos visitantes e usu&aacute;rios com avisos gerais ou personalizados relacionados a servi&ccedil;os e mensagens promocionais;</p>\r\n<p class=\"wp-block-paragraph\">&ndash; Para criar dados estat&iacute;sticos agregados e outras informa&ccedil;&otilde;es n&atilde;o pessoais agregadas e/ou inferidas, que podem ser usadas por n&oacute;s ou por nossos parceiros comerciais para prestar e melhorar nossos respectivos servi&ccedil;os;</p>\r\n<p class=\"wp-block-paragraph\">&ndash; Para cumprir quaisquer leis e regulamentos aplic&aacute;veis.</p>\r\n<p class=\"wp-block-paragraph\">​</p>\r\n<div class=\"block-title\">\r\n<h2 class=\"wp-block-heading\"><strong>4. Como armazenamos, utilizamos e compartilhamos as informa&ccedil;&otilde;es pessoais de nossos visitantes do site</strong></h2>\r\n</div>\r\n<p class=\"wp-block-paragraph\">Nosso neg&oacute;cio &eacute; hospedado na plataforma Hostgator.com. O Hostgator.com nos fornece uma plataforma online que nos permite vender produtos e servi&ccedil;os para nossos clientes. As suas informa&ccedil;&otilde;es podem ser armazenadas no banco de dados do Hostgator.com. O Hostgator.com armazena as suas informa&ccedil;&otilde;es em servidores seguros por firewall.</p>\r\n<p class=\"wp-block-paragraph\">​</p>\r\n<div class=\"block-title\">\r\n<h2 class=\"wp-block-heading\"><strong>5. Como nos comunicamos com os visitantes do nosso site</strong></h2>\r\n</div>\r\n<p class=\"wp-block-paragraph\">N&oacute;s poderemos entrar em contato para notific&aacute;-lo a respeito de sua conta, para ajud&aacute;-lo a resolver alguma quest&atilde;o relacionada &agrave; sua conta, para solucionar uma disputa de pagamento, para coletar taxas ou d&iacute;vidas, para pesquisas ou question&aacute;rios, para novidades sobre nossa empresa ou para qualquer outro motivo que seja necess&aacute;rio revisar o nosso contrato, de acordo com as leis locais. Para isso, poderemos entrar em contato via e-mail, telefone, mensagens de texto e correio.</p>\r\n<p class=\"wp-block-paragraph\">​</p>\r\n<div class=\"block-title\">\r\n<h2 class=\"wp-block-heading\"><strong>6. Como usamos os cookies e outras ferramentas de rastreamento</strong></h2>\r\n</div>\r\n<div class=\"block-title\">\r\n<h3 class=\"wp-block-heading\"><em>6.1 O que s&atilde;o Cookies?</em></h3>\r\n</div>\r\n<p class=\"wp-block-paragraph\">S&atilde;o pequenos arquivos que transferimos para o seu navegador ou dispositivo (como celular ou tablet) nos permitem reconhecer o seu navegador ou dispositivo, e saber como e quando os sites s&atilde;o utilizados. Eles podem ser &uacute;teis para, por exemplo, adequar o tamanho do site &agrave; sua tela, entender melhor as suas prefer&ecirc;ncias e lhe oferecer um servi&ccedil;o mais eficiente.</p>\r\n<p class=\"wp-block-paragraph\">Os cookies geralmente tamb&eacute;m t&ecirc;m uma data de expira&ccedil;&atilde;o. Por exemplo, alguns cookies s&atilde;o exclu&iacute;dos automaticamente quando voc&ecirc; fecha o navegador (os chamados cookies de sess&atilde;o), enquanto outros podem ser armazenados por mais tempo no computador at&eacute; serem exclu&iacute;dos manualmente (os chamados cookies persistentes).</p>\r\n<div class=\"block-title\">\r\n<h3 class=\"wp-block-heading\"><em>6.2. Quais cookies s&atilde;o utilizados em nosso site?</em></h3>\r\n</div>\r\n<p class=\"wp-block-paragraph\">Esta &eacute; a lista dos cookies que utilizamos em nossas plataformas.</p>\r\n<p class=\"wp-block-paragraph\">&middot; Cookies essenciais</p>\r\n<p class=\"wp-block-paragraph\">&middot; Cookies de prefer&ecirc;ncias e funcionalidades</p>\r\n<p class=\"wp-block-paragraph\">&middot; Cookies para envio de conte&uacute;do personalizado e publicidade</p>\r\n<p class=\"wp-block-paragraph\">&middot; Cookies para medi&ccedil;&atilde;o de desempenho do site e an&aacute;lises</p>\r\n<p class=\"wp-block-paragraph\"><em>6.3. Por que utilizamos os Cookies?</em></p>\r\n<p class=\"wp-block-paragraph\">Cookies essenciais: S&atilde;o os cookies estritamente necess&aacute;rios para fornecer nossos servi&ccedil;os e para que o nosso site funcione corretamente, garantindo a seguran&ccedil;a da navega&ccedil;&atilde;o, o correto dimensionamento do conte&uacute;do e o nosso cumprimento de obriga&ccedil;&otilde;es legais.</p>\r\n<p class=\"wp-block-paragraph\">Prefer&ecirc;ncias e funcionalidades: utilizamos cookies para maximizar a personaliza&ccedil;&atilde;o da sua experi&ecirc;ncia de navega&ccedil;&atilde;o e para permitir a ampla funcionalidade dos nossos produtos e servi&ccedil;os, armazenando algumas de suas prefer&ecirc;ncias. Por exemplo: utilizamos cookies para lembrar informa&ccedil;&otilde;es sobre seu navegador e suas prefer&ecirc;ncias de idioma e de comunica&ccedil;&atilde;o.</p>\r\n<p class=\"wp-block-paragraph\">Conte&uacute;do personalizado e publicidade: utilizamos cookies e tecnologias similares para lhe direcionar conte&uacute;do personalizado, inclusive conte&uacute;do de marketing e publicidade, a partir de informa&ccedil;&otilde;es sobre a sua intera&ccedil;&atilde;o com as nossas plataformas.</p>\r\n<p class=\"wp-block-paragraph\">Medi&ccedil;&atilde;o de desempenho do site e an&aacute;lises: utilizamos cookies para entender como os nossos produtos e servi&ccedil;os est&atilde;o sendo utilizados e, consequentemente, melhorar a sua experi&ecirc;ncia como usu&aacute;rio. Por exemplo: utilizamos cookies que realizam a coleta autom&aacute;tica de determinados dados para identificar quantas vezes determinada p&aacute;gina foi visitada ou quantas pessoas acessaram essa p&aacute;gina.</p>\r\n<p class=\"wp-block-paragraph\">De qualquer forma, voc&ecirc; sempre pode recusar a instala&ccedil;&atilde;o dos cookies descritos nessa Pol&iacute;tica e/ou optar pela remo&ccedil;&atilde;o desses cookies a qualquer momento, conforme as informa&ccedil;&otilde;es do item &ldquo;Como posso remover ou bloquear os cookies&rdquo; abaixo.</p>\r\n<div class=\"block-title\">\r\n<h3 class=\"wp-block-heading\"><em>6.4. Como posso remover ou bloquear os cookies?</em></h3>\r\n</div>\r\n<p class=\"wp-block-paragraph\">Se voc&ecirc; quiser saber quais cookies est&atilde;o instalados no seu dispositivo, ou se deseja exclu&iacute;-los ou restringi-los, voc&ecirc; pode utilizar as configura&ccedil;&otilde;es do seu navegador para isso. Nos links abaixo voc&ecirc; encontrar&aacute; os procedimentos para fazer isso.</p>\r\n<p class=\"wp-block-paragraph\"><a href=\"https://support.microsoft.com/pt-br/help/278835/how-to-delete-cookie-files-in-internet-explorer\" target=\"_blank\" rel=\"noreferrer noopener\">Internet Explorer</a></p>\r\n<p class=\"wp-block-paragraph\"><a href=\"https://support.mozilla.org/pt-BR/kb/limpe-cookies-e-dados-de-sites-no-firefox\" target=\"_blank\" rel=\"noreferrer noopener\">Firefox</a></p>\r\n<p class=\"wp-block-paragraph\"><a href=\"https://support.google.com/chrome/answer/95647?co=GENIE.Platform=Desktop&amp;hl=pt-BR\" target=\"_blank\" rel=\"noreferrer noopener\">Chrome</a></p>\r\n<p class=\"wp-block-paragraph\"><a href=\"https://support.apple.com/pt-br/guide/safari/sfri11471/mac\" target=\"_blank\" rel=\"noreferrer noopener\">Safari</a></p>\r\n<p class=\"wp-block-paragraph\">Lembrando que o uso de cookies nos permite oferecer uma melhor experi&ecirc;ncia em nossos produtos e servi&ccedil;os. Se voc&ecirc; bloquear cookies ou decidir n&atilde;o permitir o funcionamento de alguns deles, n&atilde;o teremos como garantir o correto funcionamento de todas as funcionalidades da nossa plataforma.</p>\r\n<p class=\"wp-block-paragraph\">​</p>\r\n<div class=\"block-title\">\r\n<h2 class=\"wp-block-heading\"><strong>7. Como voc&ecirc; pode retirar o seu consentimento</strong></h2>\r\n</div>\r\n<p class=\"wp-block-paragraph\">Caso voc&ecirc; n&atilde;o queira mais que seja poss&iacute;vel para n&oacute;s coletar as suas informa&ccedil;&otilde;es pessoais, fique &agrave; vontade para contatar-nos pelo e-mail&nbsp;<strong><a id=\"mailto:secretaria@ieclbparob&eacute;.com.br\" href=\"mailto:secretaria@ieclbparob%C3%A9.com.br\" type=\"mailto\">secretaria@ieclbparob&eacute;.com.br</a></strong>.</p>\r\n<p class=\"wp-block-paragraph\">&nbsp;</p>\r\n<div class=\"block-title\">\r\n<h2 class=\"wp-block-heading\"><strong>8. Atualiza&ccedil;&otilde;es da pol&iacute;tica de privacidade</strong></h2>\r\n</div>\r\n<p class=\"wp-block-paragraph\">N&oacute;s temos o direito de modificar essa pol&iacute;tica de privacidade a qualquer momento, portanto consulte regularmente. As altera&ccedil;&otilde;es e esclarecimentos ser&atilde;o imediatamente colocadas em pr&aacute;tica ap&oacute;s a altera&ccedil;&atilde;o em nosso site. Caso realizemos mudan&ccedil;as referentes aos materiais dessa pol&iacute;tica, voc&ecirc; ser&aacute; notificado para que esteja ciente das informa&ccedil;&otilde;es que coletamos e como as utilizamos.&nbsp;</p>',NULL,'publicado',NULL,NULL,'0','0','2022-01-01 00:00:00','2026-08-19 06:49:44','2026-08-19 06:50:30',NULL,NULL,'1');

DROP TABLE IF EXISTS `perfil_permissoes`;
CREATE TABLE `perfil_permissoes` (
  `perfil_id` int(10) unsigned NOT NULL,
  `permissao_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`perfil_id`,`permissao_id`),
  KEY `fk_perfil_permissoes_permissao` (`permissao_id`),
  CONSTRAINT `fk_perfil_permissoes_perfil` FOREIGN KEY (`perfil_id`) REFERENCES `perfis` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_perfil_permissoes_permissao` FOREIGN KEY (`permissao_id`) REFERENCES `permissoes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `perfil_permissoes` (`perfil_id`,`permissao_id`,`created_at`) VALUES\n('1','1','2026-08-18 19:29:06'),
('1','2','2026-08-18 19:29:06'),
('1','3','2026-08-18 19:29:06'),
('1','4','2026-08-18 19:29:06'),
('1','5','2026-08-18 19:29:06'),
('1','6','2026-08-18 19:29:06'),
('1','7','2026-08-18 19:29:06'),
('1','8','2026-08-18 19:29:06'),
('1','9','2026-08-18 19:29:06'),
('1','21','2026-08-18 19:42:49'),
('1','22','2026-08-18 19:42:49'),
('1','23','2026-08-18 19:47:38'),
('1','25','2026-08-18 20:05:59'),
('1','26','2026-08-18 20:30:46'),
('1','27','2026-08-18 21:07:45'),
('1','29','2026-08-19 06:46:54'),
('1','30','2026-08-19 06:46:54'),
('1','31','2026-08-19 06:57:23'),
('1','32','2026-08-19 06:57:23'),
('2','1','2026-08-18 19:29:06'),
('2','2','2026-08-18 19:29:06'),
('2','3','2026-08-18 19:29:06'),
('2','4','2026-08-18 19:29:06'),
('2','5','2026-08-18 19:29:06'),
('2','8','2026-08-18 19:29:06'),
('2','9','2026-08-18 19:29:06'),
('2','21','2026-08-18 19:42:49'),
('2','23','2026-08-18 19:47:38'),
('3','1','2026-08-18 19:29:06'),
('3','2','2026-08-18 19:29:06'),
('3','3','2026-08-18 19:29:06'),
('3','4','2026-08-18 19:29:06'),
('3','8','2026-08-18 19:29:06'),
('3','21','2026-08-18 19:42:49'),
('3','22','2026-08-18 19:42:49'),
('3','23','2026-08-18 19:47:38'),
('3','25','2026-08-18 20:05:59'),
('3','26','2026-08-18 20:30:46'),
('3','27','2026-08-18 21:07:45'),
('4','1','2026-08-18 19:29:06'),
('4','2','2026-08-18 19:29:06'),
('4','3','2026-08-18 19:29:06'),
('4','4','2026-08-18 19:29:06'),
('5','1','2026-08-18 19:29:06'),
('5','3','2026-08-18 19:29:06'),
('5','27','2026-08-18 21:07:45');

DROP TABLE IF EXISTS `perfis`;
CREATE TABLE `perfis` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) NOT NULL,
  `slug` varchar(80) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `perfis` (`id`,`nome`,`slug`,`created_at`) VALUES\n('1','Administrador','administrador','2026-08-18 19:29:05'),
('2','Secretaria','secretaria','2026-08-18 19:29:05'),
('3','Comunicação','comunicacao','2026-08-18 19:29:05'),
('4','Pastor','pastor','2026-08-18 19:29:05'),
('5','Moderador','moderador','2026-08-18 19:29:05');

DROP TABLE IF EXISTS `permissoes`;
CREATE TABLE `permissoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `grupo` varchar(80) NOT NULL DEFAULT 'Geral',
  `descricao` varchar(255) DEFAULT NULL,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_permissoes_grupo_ordem` (`grupo`,`ordem`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissoes` (`id`,`nome`,`slug`,`grupo`,`descricao`,`ordem`,`created_at`) VALUES\n('1','Gerenciar notícias','noticias.gerenciar','Conteúdo','Criar, editar e administrar notícias.','10','2026-08-18 19:29:06'),
('2','Gerenciar páginas','paginas.gerenciar','Conteúdo','Criar, editar e administrar páginas institucionais.','20','2026-08-18 19:29:06'),
('3','Gerenciar eventos e cultos','eventos.gerenciar','Agenda','Criar e editar eventos, cultos e agenda.','30','2026-08-18 19:29:06'),
('4','Gerenciar mídia','midias.gerenciar','Conteúdo','Enviar, editar e excluir itens da Biblioteca de Mídia.','40','2026-08-18 19:29:06'),
('5','Gerenciar comunidades','comunidades.gerenciar','Estrutura','Cadastrar e editar comunidades da paróquia.','50','2026-08-18 19:29:06'),
('6','Gerenciar usuários','usuarios.gerenciar','Administração','Criar, editar, ativar e desativar usuários.','60','2026-08-18 19:29:06'),
('7','Gerenciar perfis e permissões','permissoes.gerenciar','Administração','Definir os módulos disponíveis para cada perfil.','70','2026-08-18 19:29:06'),
('8','Gerenciar menus','menus.gerenciar','Estrutura','Administrar os menus e links públicos do portal.','80','2026-08-18 19:29:06'),
('9','Gerenciar configurações','configuracoes.gerenciar','Administração','Alterar identidade, contatos, redes sociais e SEO do portal.','90','2026-08-18 19:29:06'),
('21','Gerenciar galerias','galerias.gerenciar','Conteúdo','Criar, editar e publicar galerias de fotos.','45','2026-08-18 19:42:49'),
('22','Gerenciar banners','banners.gerenciar','Conteúdo','Administrar os banners e destaques da página inicial.','46','2026-08-18 19:42:49'),
('23','Gerenciar formulários','formularios.gerenciar','Conteúdo','Criar formulários públicos, consultar e exportar respostas.','47','2026-08-18 19:47:38'),
('25','Gerenciar SEO','seo.gerenciar','Configuração','Gerenciar metadados, redes sociais, sitemap e robots.','70','2026-08-18 20:05:59'),
('26','Gerenciar aparência','aparencia.gerenciar','Aparência',NULL,'80','2026-08-18 20:30:46'),
('27','Gerenciar comentários','comentarios.gerenciar','Conteúdo','Moderar comentários enviados nas notícias.','45','2026-08-18 21:07:44'),
('28','Editor de Temas','tema_editor.gerenciar','Aparência','Editar arquivos permitidos dos temas e restaurar backups.','86','2026-08-19 06:36:58'),
('29','Visualizar auditoria','auditoria.visualizar','Administração','Consultar e exportar registros de auditoria e segurança.','75','2026-08-19 06:46:54'),
('30','Gerenciar segurança','seguranca.gerenciar','Administração','Configurar sessão, bloqueio de login e retenção da auditoria.','76','2026-08-19 06:46:54'),
('31','Gerenciar backups','backups.gerenciar','Administração','Criar, baixar, excluir e restaurar backups do banco de dados.','77','2026-08-19 06:57:23'),
('32','Gerenciar manutenção','manutencao.gerenciar','Administração','Ativar modo manutenção e executar rotinas de limpeza.','78','2026-08-19 06:57:23');

DROP TABLE IF EXISTS `post_tags`;
CREATE TABLE `post_tags` (
  `post_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`post_id`,`tag_id`),
  KEY `idx_post_tags_tag` (`tag_id`),
  CONSTRAINT `fk_post_tags_post` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_post_tags_tag` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `comunidade_id` int(10) unsigned DEFAULT NULL,
  `categoria_id` int(10) unsigned DEFAULT NULL,
  `titulo` varchar(220) NOT NULL,
  `slug` varchar(240) NOT NULL,
  `resumo` text DEFAULT NULL,
  `conteudo` longtext NOT NULL,
  `imagem_capa` varchar(255) DEFAULT NULL,
  `imagem_capa_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('rascunho','agendado','publicado','arquivado','lixeira') NOT NULL DEFAULT 'rascunho',
  `status_anterior` varchar(20) DEFAULT NULL,
  `lixeira_em` datetime DEFAULT NULL,
  `destaque` tinyint(1) NOT NULL DEFAULT 0,
  `comentarios_ativos` tinyint(1) NOT NULL DEFAULT 1,
  `publicado_em` datetime DEFAULT NULL,
  `visualizacoes` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `seo_titulo` varchar(180) DEFAULT NULL,
  `seo_descricao` varchar(320) DEFAULT NULL,
  `seo_noindex` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_posts_autor` (`autor_id`),
  KEY `idx_posts_status_data` (`status`,`publicado_em`),
  KEY `idx_posts_comunidade` (`comunidade_id`),
  KEY `idx_posts_categoria` (`categoria_id`),
  KEY `idx_posts_imagem_capa` (`imagem_capa_id`),
  CONSTRAINT `fk_posts_autor` FOREIGN KEY (`autor_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `fk_posts_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_posts_comunidade` FOREIGN KEY (`comunidade_id`) REFERENCES `comunidades` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_posts_imagem_capa` FOREIGN KEY (`imagem_capa_id`) REFERENCES `midias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `posts` (`id`,`autor_id`,`comunidade_id`,`categoria_id`,`titulo`,`slug`,`resumo`,`conteudo`,`imagem_capa`,`imagem_capa_id`,`status`,`status_anterior`,`lixeira_em`,`destaque`,`comentarios_ativos`,`publicado_em`,`visualizacoes`,`created_at`,`updated_at`,`seo_titulo`,`seo_descricao`,`seo_noindex`) VALUES\n('1','1',NULL,'23','Neste Natal, o que você acha de fazer do seu coração uma manjedoura?','neste-natal-o-que-voc-e-acha-de-fazer-do-seu-corac-ao-uma-manjedoura','“Então Maria deu à luz o seu primeiro filho. Enrolou-o em panos e o deitou numa manjedoura, pois não havia lugar para eles na hospedaria” Lucas 2.7','<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"../../uploads/2026/08/187791a15a03ca0ce15704bb37991876654d.jpg\" alt=\"Neste Natal, o que voc&ecirc; acha de fazer do seu cora&ccedil;&atilde;o uma manjedoura?\"></p>\r\n<p class=\"wp-block-paragraph\">Quando Jos&eacute; e Maria chegaram &agrave; regi&atilde;o de Bel&eacute;m, n&atilde;o conseguiram pousada em nenhum lugar. As hospedarias estavam lotadas. O lugar que encontraram foi uma estrebaria e Jesus foi deitado numa manjedoura. A estrebaria e a manjedoura dispon&iacute;veis representam o cora&ccedil;&atilde;o que est&aacute; aberto para receber Jesus.</p>\r\n<p class=\"wp-block-paragraph\">Est&aacute; chegando o momento de pensarmos no menino que nasceu em meio a tantas dificuldades, que cresceu e se tornou o Salvador da humanidade. Nasceu Jesus, o Salvador. &Eacute; Natal e em nossos cora&ccedil;&otilde;es a esperan&ccedil;a toma vida.</p>\r\n<p class=\"wp-block-paragraph\">No Natal somos lembrados de forma muito especial do grande amor de Deus para conosco, para com a sua cria&ccedil;&atilde;o. Tamb&eacute;m neste Natal, Deus vem a n&oacute;s. Ele deseja iluminar a escurid&atilde;o na qual vivemos, deseja possibilitar o perd&atilde;o e a reconcilia&ccedil;&atilde;o.</p>\r\n<p class=\"wp-block-paragraph\">Deus vem para renovar a esperan&ccedil;a de que &eacute; poss&iacute;vel que as pessoas que ele criou, partilhem mais amor e solidariedade entre si.</p>\r\n<p class=\"wp-block-paragraph\">Tamb&eacute;m a n&oacute;s Deus diz: &ldquo;N&atilde;o temas, eu estou contigo&rdquo;. Eu te fortale&ccedil;o, sustento e ajudo. Isto &eacute; Natal: raz&atilde;o do amor, do perd&atilde;o, da esperan&ccedil;a.</p>\r\n<p class=\"wp-block-paragraph\">Vale lembrar que somos salvos por meio da bondade e do amor de Deus. Ele derramou o seu Esp&iacute;rito Santo sobre n&oacute;s por meio de Jesus Cristo, o menino nascido em Bel&eacute;m.</p>\r\n<p class=\"wp-block-paragraph\">E quando celebramos a vinda do Salvador, somos lembrados que ele &eacute; acolhido com todos os t&iacute;tulos atribu&iacute;dos a um governador: Conselheiro Maravilhoso, Deus Forte, Pai da Eternidade, Pr&iacute;ncipe da Paz (Isa&iacute;as 9.6). Por&eacute;m, ele &eacute; o oposto da maioria dos governantes que n&oacute;s conhecemos. Como escreve o pastor Geraldo Graf: &ldquo;Para aqueles que querem decidir sobre a vida dos outros, o amor de Cristo constrange e provoca. Para aqueles que incitam e praticam a viol&ecirc;ncia, a paz de Cristo incomoda.&rdquo;</p>\r\n<p class=\"wp-block-paragraph\">A mensagem de Natal quer ser anunciada, testemunhada e vivenciada por todos n&oacute;s na sociedade rompida em que vivemos. Ela quer ser uma voz prof&eacute;tica, que anuncia transforma&ccedil;&atilde;o, neste sistema que n&atilde;o promove vida.</p>\r\n<p class=\"wp-block-paragraph\">O Salvador nasceu humilde em uma estrebaria e foi deitado numa manjedoura, esse &eacute; o fato que muda a hist&oacute;ria.</p>\r\n<p class=\"wp-block-paragraph\">Que possamos nos deixar abra&ccedil;ar e fortalecer por Deus neste Natal.</p>\r\n<p class=\"wp-block-paragraph\">Ao se preparar para celebrar o Natal, que cada um fa&ccedil;a do seu cora&ccedil;&atilde;o uma manjedoura.</p>\r\n<p class=\"wp-block-paragraph\"><strong>Assim como a estrela brilhou sobre a estrebaria em Bel&eacute;m, desejamos que a luz de Deus ilumine a sua vida.<br>Assim como os anjos anunciaram paz para a terra, desejamos que a paz de Deus preencha o seu cora&ccedil;&atilde;o.<br>Assim como os magos do oriente encontraram o caminho, desejamos que tamb&eacute;m voc&ecirc; possa andar nas trilhas de Deus.<br>Assim como Maria guardou as palavras dos anjos em seu cora&ccedil;&atilde;o, desejamos que a palavra de Deus permane&ccedil;a em voc&ecirc;, orientando a sua vida.<br>Assim como os pastores reconheceram o Salvador do mundo, desejamos que voc&ecirc; possa reconhecer a Jesus Cristo como seu Redentor.</strong></p>\r\n<p class=\"wp-block-paragraph\">&nbsp;</p>\r\n<p id=\"author\" class=\"wp-block-paragraph\"><strong>Pa. Ma. T&acirc;nia Cristina Weimer</strong><br><strong>Pastora Sinodal S&iacute;nodo Nordeste Ga&uacute;cho</strong></p>\r\n<div class=\"addtoany_share_save_container addtoany_content addtoany_content_bottom\">&nbsp;</div>',NULL,'15','publicado',NULL,NULL,'0','0','2023-01-01 00:00:00','15','2026-08-18 19:50:49','2026-08-19 06:56:46',NULL,NULL,'0'),
('2','1',NULL,'24','IECLB Parobé realizou o culto de instalação da Nova Diretoria da Paroquia','ieclb-parob-e-realizou-o-culto-de-instalac-ao-da-nova-diretoria-da-paroquia',NULL,'<p class=\"wp-block-paragraph\">No &uacute;ltimo domingo, dia 29 de janeiro de 2023, aconteceu, em culto comunit&aacute;rio no templo da Comunidade Evang&eacute;lica Martin Luther de Confiss&atilde;o Luterana em Parob&eacute;, a instala&ccedil;&atilde;o da nova Diretoria e Conselho Fiscal da Par&oacute;quia Evang&eacute;lica de Confiss&atilde;o Luterana em Parob&eacute;-IECLB, eleita em Assembleia Geral Ordin&aacute;ria no dia dezenove de dezembro de 2022, para a gest&atilde;o 2023/2024. O novo Presbit&eacute;rio Paroquial, cargo e respectivo nome, fica assim constitu&iacute;do:</p>\r\n<p class=\"wp-block-paragraph\"><strong>Presidente:</strong>&nbsp;Gildomar Schneider.<br><strong>Vice-Presidente:</strong>&nbsp;Carmem Luiza Wichmann Kaufmann.<br><strong>Tesoureira:</strong>&nbsp;Patricia Maria Schmidt.<br><strong>Vice-Tesoureiro:</strong>&nbsp;Andr&eacute; Gustavo Henssler.<br><strong>Secret&aacute;ria:</strong>&nbsp;Cristiane Isamar Kohlrausch.<br><strong>Vice-Secret&aacute;ria:</strong>&nbsp;Adriana Silva Gertner.</p>\r\n<p class=\"wp-block-paragraph\"><strong>Conselho Fiscal Titular:</strong><br>Araci Elodi Lamperti.<br>Paulo Edmar Ebert.<br>Dioneia Regina Barckfeld dos Santos.</p>\r\n<p class=\"wp-block-paragraph\"><strong>Conselho Fiscal Suplente:</strong><br>Adriane Live.<br>Paulo Ricardo Schoenardie.<br>Marcolino Silveira da Silva.</p>\r\n<p class=\"wp-block-paragraph\"><strong>Tamb&eacute;m foram apresentados os representantes das Comunidades no Presbit&eacute;rio Paroquial:</strong><br><strong>por Passo dos Ferreiros:</strong>&nbsp;N&aacute;dia Maria Pohlmann.<br><strong>por Entrepelado:</strong>&nbsp;Renato Hack.<br><strong>por Santa Cruz do Pinhal:&nbsp;</strong>Isabel B&uuml;hler.<br><strong>por Fazenda Fialho:</strong>&nbsp;Claudia Cristiane Spindler.<br><strong>por Parob&eacute;:</strong>&nbsp;Cristiane Isamar Kohlrausch.</p>\r\n<p class=\"wp-block-paragraph\"><strong>Ainda foram apresentadas as representantes paroquiais no Conselho Sinodal:</strong><br><strong>Titular:</strong>&nbsp;Cristiane Isamar Kohlrausch.<br><strong>Suplente:&nbsp;</strong>Nair Marlene Sperb.</p>\r\n<p class=\"wp-block-paragraph\">O culto, celebrado pela Ministra Religiosa, Pastora Gilvania Knob de Oliveira, teve como tema &ldquo;A verdadeira felicidade&rdquo; a partir do texto b&iacute;blico de Mateus 5.1-12, previsto para 4&deg; Domingo ap&oacute;s Epifania. A ministra ressaltou a import&acirc;ncia de servir com alegria, com paix&atilde;o dentro do presbit&eacute;rio. Ao assumir um cargo de presb&iacute;tero, que se fa&ccedil;a com disposi&ccedil;&atilde;o e que se possa j&aacute; &ldquo;aqui&rdquo; desfrutar da verdadeira felicidade. No culto, tamb&eacute;m foi levada uma palavra de gratid&atilde;o aos membros do presbit&eacute;rio da gest&atilde;o 2021/2023.</p>\r\n<p class=\"wp-block-paragraph\">Na certeza que onde estiverem Deus est&aacute; presente, a par&oacute;quia deseja as mais ricas b&ecirc;n&ccedil;&atilde;os de Deus na vida dos presb&iacute;teros e de suas fam&iacute;lias, assim como a todos os membros que formam as comunidades crist&atilde;s.</p>',NULL,'19','publicado',NULL,NULL,'0','0','2023-02-02 20:25:00','1','2026-08-18 21:10:44','2026-08-19 06:56:29',NULL,NULL,'0'),
('3','1',NULL,'1','EU NÃO… TÔ FORA!','eu-n-ao-t-o-fora',NULL,'<p><em>&ldquo;Levem os fardos pesados uns dos outros e, assim, cumpram a lei de Cristo.&rdquo;&nbsp;</em>(G&aacute;latas 6.2)</p>\r\n<p>Estimados irm&atilde;os e irm&atilde;s. Certamente, em alguma ocasi&atilde;o da vida, voc&ecirc; j&aacute; se deparou com alguma situa&ccedil;&atilde;o onde as pessoas a sua volta come&ccedil;aram a abandonar algum trabalho ou tarefa em grupo que haviam assumido, quer seja a condu&ccedil;&atilde;o e reuni&atilde;o de um grupo ou um trabalho em conjunto, ou uma tarefa al&eacute;m do lugar onde est&atilde;o.</p>\r\n<p>Creio eu que, dependendo da situa&ccedil;&atilde;o, foi at&eacute; f&aacute;cil desistir do compromisso assumido e at&eacute; gerou um al&iacute;vio por n&atilde;o precisar mais estar ali naquele determinado dia e hor&aacute;rio, e ter a agenda livre para fazer alguma outra coisa ou at&eacute; mesmo descansar. Talvez, no decorrer do tempo, at&eacute; uma saudade foi se criando sobre aquilo que se tinha e agora n&atilde;o existe mais.</p>\r\n<p>Eu diria que &eacute; perfeitamente normal que isso aconte&ccedil;a dentro de nossa vida, quer seja social ou comunit&aacute;ria, pois nem tudo dura para sempre, e uma hora as coisas acabam e deixam saudades. Mas e agora, o que faremos para rever essas pessoas, para conversar com elas, cuidar, aconselhar e ouvir elas em suas d&uacute;vidas, dores, queixas e fardos, al&eacute;m do culto comunit&aacute;rio?</p>\r\n<p>&Eacute; nesse momento que vamos perceber que, talvez, nosso grupo n&atilde;o era apenas um ajuntamento de pessoas, mas sim, um local de cuidado, partilha, aux&iacute;lio, acolhida, fortalecimento e at&eacute; mesmo de al&iacute;vio, e a&iacute; precisaremos ir novamente at&eacute; aquelas pessoas que nos cuidavam.</p>\r\n<p>Em nossa comunidade sempre vamos ter espa&ccedil;os para partilhar a nossa vida com seus acontecimentos alegres e tristes, com nossas conquistas e derrotas, com nossas d&uacute;vidas e respostas. Ali vamos aprender a auxiliar uns aos outros para carregarmos os fardos que temos. E que bom &eacute; quando podemos ter algu&eacute;m para nos ajudar ou podemos ajudar outra pessoa.</p>\r\n<p>At&eacute; mesmo no trabalho comunit&aacute;rio, em uma reforma, uma festividade ou atividade, quando somos chamados a ajudar, &eacute; necess&aacute;rio que o fa&ccedil;amos com alegria, para que o nosso pensamento n&atilde;o seja: &ldquo;bah, mas eu j&aacute; fiz tanta coisa. Eu n&atilde;o vou dessa vez&hellip; Estou fora&rdquo;. Para que ali tamb&eacute;m venhamos a colher juntos as b&ecirc;n&ccedil;&atilde;os de partilhar fardos.</p>\r\n<p>Que ao inv&eacute;s de nos negarmos, a frase que sair&aacute; de nossa boca possa ser: &ldquo;Eu n&atilde;o estou fora!&rdquo; para que assim, sigamos a construir a hist&oacute;ria de nossa comunidade, fazendo dela um lugar de acolhida, partilha, crescimento e fortalecimento da f&eacute;.</p>\r\n<p><strong>Ora&ccedil;&atilde;o:&nbsp;</strong>Amado Pai, eu te louvo por poder partilhar os pesos da vida e por poder cuidar de outras pessoas em nossas comunidades. Em nome de Jesus. Am&eacute;m.</p>\r\n<p id=\"author\"><strong>Pastor Adelar Appelt</strong><br><strong>Par&oacute;quia Evang&eacute;lica de S&atilde;o Jos&eacute; do Hort&ecirc;ncio</strong></p>',NULL,'20','publicado',NULL,NULL,'0','0','2023-02-17 10:41:00','1','2026-08-19 06:45:39','2026-08-19 06:45:51',NULL,NULL,'0');

DROP TABLE IF EXISTS `revisoes`;
CREATE TABLE `revisoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` enum('post','pagina') NOT NULL,
  `conteudo_id` int(10) unsigned NOT NULL,
  `autor_id` int(10) unsigned DEFAULT NULL,
  `dados` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_revisoes_tipo_conteudo` (`tipo`,`conteudo_id`,`id`),
  KEY `idx_revisoes_autor` (`autor_id`),
  CONSTRAINT `fk_revisoes_autor` FOREIGN KEY (`autor_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `revisoes` (`id`,`tipo`,`conteudo_id`,`autor_id`,`dados`,`created_at`) VALUES\n('1','post','1','1','{\"record\":{\"id\":1,\"autor_id\":1,\"comunidade_id\":null,\"categoria_id\":1,\"titulo\":\"Neste Natal, o que você acha de fazer do seu coração uma manjedoura?\",\"slug\":\"neste-natal-o-que-voc-e-acha-de-fazer-do-seu-corac-ao-uma-manjedoura\",\"resumo\":\"“Então Maria deu à luz o seu primeiro filho. Enrolou-o em panos e o deitou numa manjedoura, pois não havia lugar para eles na hospedaria” Lucas 2.7\",\"conteudo\":\"<p><img style=\\\"display: block; margin-left: auto; margin-right: auto;\\\" src=\\\"../../uploads/2026/08/187791a15a03ca0ce15704bb37991876654d.jpg\\\" alt=\\\"Neste Natal, o que voc&ecirc; acha de fazer do seu cora&ccedil;&atilde;o uma manjedoura?\\\"></p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Quando Jos&eacute; e Maria chegaram &agrave; regi&atilde;o de Bel&eacute;m, n&atilde;o conseguiram pousada em nenhum lugar. As hospedarias estavam lotadas. O lugar que encontraram foi uma estrebaria e Jesus foi deitado numa manjedoura. A estrebaria e a manjedoura dispon&iacute;veis representam o cora&ccedil;&atilde;o que est&aacute; aberto para receber Jesus.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Est&aacute; chegando o momento de pensarmos no menino que nasceu em meio a tantas dificuldades, que cresceu e se tornou o Salvador da humanidade. Nasceu Jesus, o Salvador. &Eacute; Natal e em nossos cora&ccedil;&otilde;es a esperan&ccedil;a toma vida.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">No Natal somos lembrados de forma muito especial do grande amor de Deus para conosco, para com a sua cria&ccedil;&atilde;o. Tamb&eacute;m neste Natal, Deus vem a n&oacute;s. Ele deseja iluminar a escurid&atilde;o na qual vivemos, deseja possibilitar o perd&atilde;o e a reconcilia&ccedil;&atilde;o.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Deus vem para renovar a esperan&ccedil;a de que &eacute; poss&iacute;vel que as pessoas que ele criou, partilhem mais amor e solidariedade entre si.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Tamb&eacute;m a n&oacute;s Deus diz: &ldquo;N&atilde;o temas, eu estou contigo&rdquo;. Eu te fortale&ccedil;o, sustento e ajudo. Isto &eacute; Natal: raz&atilde;o do amor, do perd&atilde;o, da esperan&ccedil;a.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Vale lembrar que somos salvos por meio da bondade e do amor de Deus. Ele derramou o seu Esp&iacute;rito Santo sobre n&oacute;s por meio de Jesus Cristo, o menino nascido em Bel&eacute;m.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">E quando celebramos a vinda do Salvador, somos lembrados que ele &eacute; acolhido com todos os t&iacute;tulos atribu&iacute;dos a um governador: Conselheiro Maravilhoso, Deus Forte, Pai da Eternidade, Pr&iacute;ncipe da Paz (Isa&iacute;as 9.6). Por&eacute;m, ele &eacute; o oposto da maioria dos governantes que n&oacute;s conhecemos. Como escreve o pastor Geraldo Graf: &ldquo;Para aqueles que querem decidir sobre a vida dos outros, o amor de Cristo constrange e provoca. Para aqueles que incitam e praticam a viol&ecirc;ncia, a paz de Cristo incomoda.&rdquo;</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">A mensagem de Natal quer ser anunciada, testemunhada e vivenciada por todos n&oacute;s na sociedade rompida em que vivemos. Ela quer ser uma voz prof&eacute;tica, que anuncia transforma&ccedil;&atilde;o, neste sistema que n&atilde;o promove vida.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">O Salvador nasceu humilde em uma estrebaria e foi deitado numa manjedoura, esse &eacute; o fato que muda a hist&oacute;ria.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Que possamos nos deixar abra&ccedil;ar e fortalecer por Deus neste Natal.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Ao se preparar para celebrar o Natal, que cada um fa&ccedil;a do seu cora&ccedil;&atilde;o uma manjedoura.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><strong>Assim como a estrela brilhou sobre a estrebaria em Bel&eacute;m, desejamos que a luz de Deus ilumine a sua vida.<br>Assim como os anjos anunciaram paz para a terra, desejamos que a paz de Deus preencha o seu cora&ccedil;&atilde;o.<br>Assim como os magos do oriente encontraram o caminho, desejamos que tamb&eacute;m voc&ecirc; possa andar nas trilhas de Deus.<br>Assim como Maria guardou as palavras dos anjos em seu cora&ccedil;&atilde;o, desejamos que a palavra de Deus permane&ccedil;a em voc&ecirc;, orientando a sua vida.<br>Assim como os pastores reconheceram o Salvador do mundo, desejamos que voc&ecirc; possa reconhecer a Jesus Cristo como seu Redentor.</strong></p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&nbsp;</p>\\r\\n<p id=\\\"author\\\" class=\\\"wp-block-paragraph\\\"><strong>Pa. Ma. T&acirc;nia Cristina Weimer</strong><br><strong>Pastora Sinodal S&iacute;nodo Nordeste Ga&uacute;cho</strong></p>\\r\\n<div class=\\\"addtoany_share_save_container addtoany_content addtoany_content_bottom\\\">&nbsp;</div>\",\"imagem_capa\":null,\"imagem_capa_id\":15,\"status\":\"publicado\",\"status_anterior\":null,\"lixeira_em\":null,\"destaque\":0,\"comentarios_ativos\":0,\"publicado_em\":\"2023-01-01 00:00:00\",\"visualizacoes\":14,\"created_at\":\"2026-08-18 19:50:49\",\"updated_at\":\"2026-08-18 21:18:33\",\"seo_titulo\":null,\"seo_descricao\":null,\"seo_noindex\":0},\"tags\":[]}','2026-08-18 21:18:44'),
('2','post','1','1','{\"record\":{\"id\":1,\"autor_id\":1,\"comunidade_id\":null,\"categoria_id\":1,\"titulo\":\"Neste Natal, o que você acha de fazer do seu coração uma manjedoura?\",\"slug\":\"neste-natal-o-que-voc-e-acha-de-fazer-do-seu-corac-ao-uma-manjedoura\",\"resumo\":\"“Então Maria deu à luz o seu primeiro filho. Enrolou-o em panos e o deitou numa manjedoura, pois não havia lugar para eles na hospedaria” Lucas 2.7\",\"conteudo\":\"<p><img style=\\\"display: block; margin-left: auto; margin-right: auto;\\\" src=\\\"../../uploads/2026/08/187791a15a03ca0ce15704bb37991876654d.jpg\\\" alt=\\\"Neste Natal, o que voc&ecirc; acha de fazer do seu cora&ccedil;&atilde;o uma manjedoura?\\\"></p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Quando Jos&eacute; e Maria chegaram &agrave; regi&atilde;o de Bel&eacute;m, n&atilde;o conseguiram pousada em nenhum lugar. As hospedarias estavam lotadas. O lugar que encontraram foi uma estrebaria e Jesus foi deitado numa manjedoura. A estrebaria e a manjedoura dispon&iacute;veis representam o cora&ccedil;&atilde;o que est&aacute; aberto para receber Jesus.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Est&aacute; chegando o momento de pensarmos no menino que nasceu em meio a tantas dificuldades, que cresceu e se tornou o Salvador da humanidade. Nasceu Jesus, o Salvador. &Eacute; Natal e em nossos cora&ccedil;&otilde;es a esperan&ccedil;a toma vida.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">No Natal somos lembrados de forma muito especial do grande amor de Deus para conosco, para com a sua cria&ccedil;&atilde;o. Tamb&eacute;m neste Natal, Deus vem a n&oacute;s. Ele deseja iluminar a escurid&atilde;o na qual vivemos, deseja possibilitar o perd&atilde;o e a reconcilia&ccedil;&atilde;o.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Deus vem para renovar a esperan&ccedil;a de que &eacute; poss&iacute;vel que as pessoas que ele criou, partilhem mais amor e solidariedade entre si.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Tamb&eacute;m a n&oacute;s Deus diz: &ldquo;N&atilde;o temas, eu estou contigo&rdquo;. Eu te fortale&ccedil;o, sustento e ajudo. Isto &eacute; Natal: raz&atilde;o do amor, do perd&atilde;o, da esperan&ccedil;a.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Vale lembrar que somos salvos por meio da bondade e do amor de Deus. Ele derramou o seu Esp&iacute;rito Santo sobre n&oacute;s por meio de Jesus Cristo, o menino nascido em Bel&eacute;m.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">E quando celebramos a vinda do Salvador, somos lembrados que ele &eacute; acolhido com todos os t&iacute;tulos atribu&iacute;dos a um governador: Conselheiro Maravilhoso, Deus Forte, Pai da Eternidade, Pr&iacute;ncipe da Paz (Isa&iacute;as 9.6). Por&eacute;m, ele &eacute; o oposto da maioria dos governantes que n&oacute;s conhecemos. Como escreve o pastor Geraldo Graf: &ldquo;Para aqueles que querem decidir sobre a vida dos outros, o amor de Cristo constrange e provoca. Para aqueles que incitam e praticam a viol&ecirc;ncia, a paz de Cristo incomoda.&rdquo;</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">A mensagem de Natal quer ser anunciada, testemunhada e vivenciada por todos n&oacute;s na sociedade rompida em que vivemos. Ela quer ser uma voz prof&eacute;tica, que anuncia transforma&ccedil;&atilde;o, neste sistema que n&atilde;o promove vida.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">O Salvador nasceu humilde em uma estrebaria e foi deitado numa manjedoura, esse &eacute; o fato que muda a hist&oacute;ria.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Que possamos nos deixar abra&ccedil;ar e fortalecer por Deus neste Natal.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Ao se preparar para celebrar o Natal, que cada um fa&ccedil;a do seu cora&ccedil;&atilde;o uma manjedoura.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><strong>Assim como a estrela brilhou sobre a estrebaria em Bel&eacute;m, desejamos que a luz de Deus ilumine a sua vida.<br>Assim como os anjos anunciaram paz para a terra, desejamos que a paz de Deus preencha o seu cora&ccedil;&atilde;o.<br>Assim como os magos do oriente encontraram o caminho, desejamos que tamb&eacute;m voc&ecirc; possa andar nas trilhas de Deus.<br>Assim como Maria guardou as palavras dos anjos em seu cora&ccedil;&atilde;o, desejamos que a palavra de Deus permane&ccedil;a em voc&ecirc;, orientando a sua vida.<br>Assim como os pastores reconheceram o Salvador do mundo, desejamos que voc&ecirc; possa reconhecer a Jesus Cristo como seu Redentor.</strong></p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&nbsp;</p>\\r\\n<p id=\\\"author\\\" class=\\\"wp-block-paragraph\\\"><strong>Pa. Ma. T&acirc;nia Cristina Weimer</strong><br><strong>Pastora Sinodal S&iacute;nodo Nordeste Ga&uacute;cho</strong></p>\\r\\n<div class=\\\"addtoany_share_save_container addtoany_content addtoany_content_bottom\\\">&nbsp;</div>\",\"imagem_capa\":null,\"imagem_capa_id\":15,\"status\":\"arquivado\",\"status_anterior\":null,\"lixeira_em\":null,\"destaque\":0,\"comentarios_ativos\":0,\"publicado_em\":\"2023-01-01 00:00:00\",\"visualizacoes\":14,\"created_at\":\"2026-08-18 19:50:49\",\"updated_at\":\"2026-08-18 21:18:44\",\"seo_titulo\":null,\"seo_descricao\":null,\"seo_noindex\":0},\"tags\":[]}','2026-08-18 21:18:53'),
('3','pagina','1','1','{\"record\":{\"id\":1,\"autor_id\":1,\"titulo\":\"Política de Privacidade\",\"slug\":\"pol-itica-de-privacidade\",\"resumo\":null,\"conteudo\":\"<div class=\\\"block-title\\\">\\r\\n<h2 class=\\\"wp-block-heading\\\"><strong>1. Quais os tipos de informa&ccedil;&atilde;o coletamos</strong></h2>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">N&oacute;s recebemos, coletamos e arquivamos as informa&ccedil;&otilde;es que voc&ecirc; adiciona em nosso site ou nos fornece de qualquer outra forma. Al&eacute;m disso, n&oacute;s coletamos o endere&ccedil;o IP utilizado para conectar o seu computador &agrave; Internet; dados de login; endere&ccedil;o de e-mail; senha; informa&ccedil;&otilde;es do computador e internet e hist&oacute;rico de compra. N&oacute;s poderemos utilizar ferramentas para medir e coletar informa&ccedil;&otilde;es de navega&ccedil;&atilde;o, incluindo o tempo de resposta das p&aacute;ginas, tempo total da visita em determinadas p&aacute;ginas, informa&ccedil;&otilde;es de intera&ccedil;&atilde;o com p&aacute;gina e os m&eacute;todos utilizados para deixar a p&aacute;gina. N&oacute;s tamb&eacute;m coletamos informa&ccedil;&otilde;es de identifica&ccedil;&atilde;o pessoal (incluindo nome, e-mail, senha, meios de comunica&ccedil;&atilde;o); coment&aacute;rios, feedback, recomenda&ccedil;&otilde;es e perfil pessoal.&nbsp;</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">​</p>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h2 class=\\\"wp-block-heading\\\"><strong>2. Como coletamos essas informa&ccedil;&otilde;es</strong></h2>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">Quando voc&ecirc; realiza uma opera&ccedil;&atilde;o em nosso site, como parte do procedimento, n&oacute;s coletamos as informa&ccedil;&otilde;es pessoais fornecidas como o seu nome, endere&ccedil;o e endere&ccedil;o de e-mail. As suas informa&ccedil;&otilde;es pessoais ser&atilde;o utilizadas apenas para as a&ccedil;&otilde;es espec&iacute;ficas citadas abaixo.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">​</p>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h2 class=\\\"wp-block-heading\\\"><strong>3. Por que coletamos essas informa&ccedil;&otilde;es pessoais</strong></h2>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">&ndash; Para prestar aos nossos usu&aacute;rios assist&ecirc;ncia e suporte t&eacute;cnico cont&iacute;nuos ao cliente;</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&ndash; Para prestar e operar os Servi&ccedil;os;</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&ndash; Para fornecer aos nossos usu&aacute;rios assist&ecirc;ncia ao cliente cont&iacute;nua e suporte t&eacute;cnico;</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&ndash; Para poder entrar em contato com nossos visitantes e usu&aacute;rios com avisos gerais ou personalizados relacionados a servi&ccedil;os e mensagens promocionais;</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&ndash; Para criar dados estat&iacute;sticos agregados e outras informa&ccedil;&otilde;es n&atilde;o pessoais agregadas e/ou inferidas, que podem ser usadas por n&oacute;s ou por nossos parceiros comerciais para prestar e melhorar nossos respectivos servi&ccedil;os;</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&ndash; Para cumprir quaisquer leis e regulamentos aplic&aacute;veis.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">​</p>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h2 class=\\\"wp-block-heading\\\"><strong>4. Como armazenamos, utilizamos e compartilhamos as informa&ccedil;&otilde;es pessoais de nossos visitantes do site</strong></h2>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">Nosso neg&oacute;cio &eacute; hospedado na plataforma Hostgator.com. O Hostgator.com nos fornece uma plataforma online que nos permite vender produtos e servi&ccedil;os para nossos clientes. As suas informa&ccedil;&otilde;es podem ser armazenadas no banco de dados do Hostgator.com. O Hostgator.com armazena as suas informa&ccedil;&otilde;es em servidores seguros por firewall.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">​</p>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h2 class=\\\"wp-block-heading\\\"><strong>5. Como nos comunicamos com os visitantes do nosso site</strong></h2>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">N&oacute;s poderemos entrar em contato para notific&aacute;-lo a respeito de sua conta, para ajud&aacute;-lo a resolver alguma quest&atilde;o relacionada &agrave; sua conta, para solucionar uma disputa de pagamento, para coletar taxas ou d&iacute;vidas, para pesquisas ou question&aacute;rios, para novidades sobre nossa empresa ou para qualquer outro motivo que seja necess&aacute;rio revisar o nosso contrato, de acordo com as leis locais. Para isso, poderemos entrar em contato via e-mail, telefone, mensagens de texto e correio.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">​</p>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h2 class=\\\"wp-block-heading\\\"><strong>6. Como usamos os cookies e outras ferramentas de rastreamento</strong></h2>\\r\\n</div>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h3 class=\\\"wp-block-heading\\\"><em>6.1 O que s&atilde;o Cookies?</em></h3>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">S&atilde;o pequenos arquivos que transferimos para o seu navegador ou dispositivo (como celular ou tablet) nos permitem reconhecer o seu navegador ou dispositivo, e saber como e quando os sites s&atilde;o utilizados. Eles podem ser &uacute;teis para, por exemplo, adequar o tamanho do site &agrave; sua tela, entender melhor as suas prefer&ecirc;ncias e lhe oferecer um servi&ccedil;o mais eficiente.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Os cookies geralmente tamb&eacute;m t&ecirc;m uma data de expira&ccedil;&atilde;o. Por exemplo, alguns cookies s&atilde;o exclu&iacute;dos automaticamente quando voc&ecirc; fecha o navegador (os chamados cookies de sess&atilde;o), enquanto outros podem ser armazenados por mais tempo no computador at&eacute; serem exclu&iacute;dos manualmente (os chamados cookies persistentes).</p>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h3 class=\\\"wp-block-heading\\\"><em>6.2. Quais cookies s&atilde;o utilizados em nosso site?</em></h3>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">Esta &eacute; a lista dos cookies que utilizamos em nossas plataformas.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&middot; Cookies essenciais</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&middot; Cookies de prefer&ecirc;ncias e funcionalidades</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&middot; Cookies para envio de conte&uacute;do personalizado e publicidade</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&middot; Cookies para medi&ccedil;&atilde;o de desempenho do site e an&aacute;lises</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><em>6.3. Por que utilizamos os Cookies?</em></p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Cookies essenciais: S&atilde;o os cookies estritamente necess&aacute;rios para fornecer nossos servi&ccedil;os e para que o nosso site funcione corretamente, garantindo a seguran&ccedil;a da navega&ccedil;&atilde;o, o correto dimensionamento do conte&uacute;do e o nosso cumprimento de obriga&ccedil;&otilde;es legais.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Prefer&ecirc;ncias e funcionalidades: utilizamos cookies para maximizar a personaliza&ccedil;&atilde;o da sua experi&ecirc;ncia de navega&ccedil;&atilde;o e para permitir a ampla funcionalidade dos nossos produtos e servi&ccedil;os, armazenando algumas de suas prefer&ecirc;ncias. Por exemplo: utilizamos cookies para lembrar informa&ccedil;&otilde;es sobre seu navegador e suas prefer&ecirc;ncias de idioma e de comunica&ccedil;&atilde;o.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Conte&uacute;do personalizado e publicidade: utilizamos cookies e tecnologias similares para lhe direcionar conte&uacute;do personalizado, inclusive conte&uacute;do de marketing e publicidade, a partir de informa&ccedil;&otilde;es sobre a sua intera&ccedil;&atilde;o com as nossas plataformas.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Medi&ccedil;&atilde;o de desempenho do site e an&aacute;lises: utilizamos cookies para entender como os nossos produtos e servi&ccedil;os est&atilde;o sendo utilizados e, consequentemente, melhorar a sua experi&ecirc;ncia como usu&aacute;rio. Por exemplo: utilizamos cookies que realizam a coleta autom&aacute;tica de determinados dados para identificar quantas vezes determinada p&aacute;gina foi visitada ou quantas pessoas acessaram essa p&aacute;gina.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">De qualquer forma, voc&ecirc; sempre pode recusar a instala&ccedil;&atilde;o dos cookies descritos nessa Pol&iacute;tica e/ou optar pela remo&ccedil;&atilde;o desses cookies a qualquer momento, conforme as informa&ccedil;&otilde;es do item &ldquo;Como posso remover ou bloquear os cookies&rdquo; abaixo.</p>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h3 class=\\\"wp-block-heading\\\"><em>6.4. Como posso remover ou bloquear os cookies?</em></h3>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">Se voc&ecirc; quiser saber quais cookies est&atilde;o instalados no seu dispositivo, ou se deseja exclu&iacute;-los ou restringi-los, voc&ecirc; pode utilizar as configura&ccedil;&otilde;es do seu navegador para isso. Nos links abaixo voc&ecirc; encontrar&aacute; os procedimentos para fazer isso.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><a href=\\\"https://support.microsoft.com/pt-br/help/278835/how-to-delete-cookie-files-in-internet-explorer\\\" target=\\\"_blank\\\" rel=\\\"noreferrer noopener\\\">Internet Explorer</a></p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><a href=\\\"https://support.mozilla.org/pt-BR/kb/limpe-cookies-e-dados-de-sites-no-firefox\\\" target=\\\"_blank\\\" rel=\\\"noreferrer noopener\\\">Firefox</a></p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><a href=\\\"https://support.google.com/chrome/answer/95647?co=GENIE.Platform=Desktop&amp;hl=pt-BR\\\" target=\\\"_blank\\\" rel=\\\"noreferrer noopener\\\">Chrome</a></p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><a href=\\\"https://support.apple.com/pt-br/guide/safari/sfri11471/mac\\\" target=\\\"_blank\\\" rel=\\\"noreferrer noopener\\\">Safari</a></p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Lembrando que o uso de cookies nos permite oferecer uma melhor experi&ecirc;ncia em nossos produtos e servi&ccedil;os. Se voc&ecirc; bloquear cookies ou decidir n&atilde;o permitir o funcionamento de alguns deles, n&atilde;o teremos como garantir o correto funcionamento de todas as funcionalidades da nossa plataforma.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">​</p>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h2 class=\\\"wp-block-heading\\\"><strong>7. Como voc&ecirc; pode retirar o seu consentimento</strong></h2>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">Caso voc&ecirc; n&atilde;o queira mais que seja poss&iacute;vel para n&oacute;s coletar as suas informa&ccedil;&otilde;es pessoais, fique &agrave; vontade para contatar-nos pelo e-mail&nbsp;<strong><a id=\\\"mailto:secretaria@ieclbparob&eacute;.com.br\\\" href=\\\"mailto:secretaria@ieclbparob%C3%A9.com.br\\\" type=\\\"mailto\\\">secretaria@ieclbparob&eacute;.com.br</a></strong>.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&nbsp;</p>\\r\\n<div class=\\\"block-title\\\">\\r\\n<h2 class=\\\"wp-block-heading\\\"><strong>8. Atualiza&ccedil;&otilde;es da pol&iacute;tica de privacidade</strong></h2>\\r\\n</div>\\r\\n<p class=\\\"wp-block-paragraph\\\">N&oacute;s temos o direito de modificar essa pol&iacute;tica de privacidade a qualquer momento, portanto consulte regularmente. As altera&ccedil;&otilde;es e esclarecimentos ser&atilde;o imediatamente colocadas em pr&aacute;tica ap&oacute;s a altera&ccedil;&atilde;o em nosso site. Caso realizemos mudan&ccedil;as referentes aos materiais dessa pol&iacute;tica, voc&ecirc; ser&aacute; notificado para que esteja ciente das informa&ccedil;&otilde;es que coletamos e como as utilizamos.&nbsp;</p>\",\"imagem_capa_id\":null,\"status\":\"publicado\",\"status_anterior\":null,\"lixeira_em\":null,\"exibir_menu\":0,\"ordem\":0,\"publicado_em\":\"2022-01-01 00:00:00\",\"created_at\":\"2026-08-19 06:49:44\",\"updated_at\":\"2026-08-19 06:49:44\",\"seo_titulo\":null,\"seo_descricao\":null,\"seo_noindex\":1}}','2026-08-19 06:50:30'),
('4','post','2','1','{\"record\":{\"id\":2,\"autor_id\":1,\"comunidade_id\":null,\"categoria_id\":1,\"titulo\":\"IECLB Parobé realizou o culto de instalação da Nova Diretoria da Paroquia\",\"slug\":\"ieclb-parob-e-realizou-o-culto-de-instalac-ao-da-nova-diretoria-da-paroquia\",\"resumo\":null,\"conteudo\":\"<p class=\\\"wp-block-paragraph\\\">No &uacute;ltimo domingo, dia 29 de janeiro de 2023, aconteceu, em culto comunit&aacute;rio no templo da Comunidade Evang&eacute;lica Martin Luther de Confiss&atilde;o Luterana em Parob&eacute;, a instala&ccedil;&atilde;o da nova Diretoria e Conselho Fiscal da Par&oacute;quia Evang&eacute;lica de Confiss&atilde;o Luterana em Parob&eacute;-IECLB, eleita em Assembleia Geral Ordin&aacute;ria no dia dezenove de dezembro de 2022, para a gest&atilde;o 2023/2024. O novo Presbit&eacute;rio Paroquial, cargo e respectivo nome, fica assim constitu&iacute;do:</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><strong>Presidente:</strong>&nbsp;Gildomar Schneider.<br><strong>Vice-Presidente:</strong>&nbsp;Carmem Luiza Wichmann Kaufmann.<br><strong>Tesoureira:</strong>&nbsp;Patricia Maria Schmidt.<br><strong>Vice-Tesoureiro:</strong>&nbsp;Andr&eacute; Gustavo Henssler.<br><strong>Secret&aacute;ria:</strong>&nbsp;Cristiane Isamar Kohlrausch.<br><strong>Vice-Secret&aacute;ria:</strong>&nbsp;Adriana Silva Gertner.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><strong>Conselho Fiscal Titular:</strong><br>Araci Elodi Lamperti.<br>Paulo Edmar Ebert.<br>Dioneia Regina Barckfeld dos Santos.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><strong>Conselho Fiscal Suplente:</strong><br>Adriane Live.<br>Paulo Ricardo Schoenardie.<br>Marcolino Silveira da Silva.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><strong>Tamb&eacute;m foram apresentados os representantes das Comunidades no Presbit&eacute;rio Paroquial:</strong><br><strong>por Passo dos Ferreiros:</strong>&nbsp;N&aacute;dia Maria Pohlmann.<br><strong>por Entrepelado:</strong>&nbsp;Renato Hack.<br><strong>por Santa Cruz do Pinhal:&nbsp;</strong>Isabel B&uuml;hler.<br><strong>por Fazenda Fialho:</strong>&nbsp;Claudia Cristiane Spindler.<br><strong>por Parob&eacute;:</strong>&nbsp;Cristiane Isamar Kohlrausch.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><strong>Ainda foram apresentadas as representantes paroquiais no Conselho Sinodal:</strong><br><strong>Titular:</strong>&nbsp;Cristiane Isamar Kohlrausch.<br><strong>Suplente:&nbsp;</strong>Nair Marlene Sperb.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">O culto, celebrado pela Ministra Religiosa, Pastora Gilvania Knob de Oliveira, teve como tema &ldquo;A verdadeira felicidade&rdquo; a partir do texto b&iacute;blico de Mateus 5.1-12, previsto para 4&deg; Domingo ap&oacute;s Epifania. A ministra ressaltou a import&acirc;ncia de servir com alegria, com paix&atilde;o dentro do presbit&eacute;rio. Ao assumir um cargo de presb&iacute;tero, que se fa&ccedil;a com disposi&ccedil;&atilde;o e que se possa j&aacute; &ldquo;aqui&rdquo; desfrutar da verdadeira felicidade. No culto, tamb&eacute;m foi levada uma palavra de gratid&atilde;o aos membros do presbit&eacute;rio da gest&atilde;o 2021/2023.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Na certeza que onde estiverem Deus est&aacute; presente, a par&oacute;quia deseja as mais ricas b&ecirc;n&ccedil;&atilde;os de Deus na vida dos presb&iacute;teros e de suas fam&iacute;lias, assim como a todos os membros que formam as comunidades crist&atilde;s.</p>\",\"imagem_capa\":null,\"imagem_capa_id\":19,\"status\":\"publicado\",\"status_anterior\":null,\"lixeira_em\":null,\"destaque\":0,\"comentarios_ativos\":0,\"publicado_em\":\"2023-02-02 20:25:00\",\"visualizacoes\":1,\"created_at\":\"2026-08-18 21:10:44\",\"updated_at\":\"2026-08-18 21:10:50\",\"seo_titulo\":null,\"seo_descricao\":null,\"seo_noindex\":0},\"tags\":[]}','2026-08-19 06:56:29'),
('5','post','1','1','{\"record\":{\"id\":1,\"autor_id\":1,\"comunidade_id\":null,\"categoria_id\":1,\"titulo\":\"Neste Natal, o que você acha de fazer do seu coração uma manjedoura?\",\"slug\":\"neste-natal-o-que-voc-e-acha-de-fazer-do-seu-corac-ao-uma-manjedoura\",\"resumo\":\"“Então Maria deu à luz o seu primeiro filho. Enrolou-o em panos e o deitou numa manjedoura, pois não havia lugar para eles na hospedaria” Lucas 2.7\",\"conteudo\":\"<p><img style=\\\"display: block; margin-left: auto; margin-right: auto;\\\" src=\\\"../../uploads/2026/08/187791a15a03ca0ce15704bb37991876654d.jpg\\\" alt=\\\"Neste Natal, o que voc&ecirc; acha de fazer do seu cora&ccedil;&atilde;o uma manjedoura?\\\"></p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Quando Jos&eacute; e Maria chegaram &agrave; regi&atilde;o de Bel&eacute;m, n&atilde;o conseguiram pousada em nenhum lugar. As hospedarias estavam lotadas. O lugar que encontraram foi uma estrebaria e Jesus foi deitado numa manjedoura. A estrebaria e a manjedoura dispon&iacute;veis representam o cora&ccedil;&atilde;o que est&aacute; aberto para receber Jesus.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Est&aacute; chegando o momento de pensarmos no menino que nasceu em meio a tantas dificuldades, que cresceu e se tornou o Salvador da humanidade. Nasceu Jesus, o Salvador. &Eacute; Natal e em nossos cora&ccedil;&otilde;es a esperan&ccedil;a toma vida.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">No Natal somos lembrados de forma muito especial do grande amor de Deus para conosco, para com a sua cria&ccedil;&atilde;o. Tamb&eacute;m neste Natal, Deus vem a n&oacute;s. Ele deseja iluminar a escurid&atilde;o na qual vivemos, deseja possibilitar o perd&atilde;o e a reconcilia&ccedil;&atilde;o.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Deus vem para renovar a esperan&ccedil;a de que &eacute; poss&iacute;vel que as pessoas que ele criou, partilhem mais amor e solidariedade entre si.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Tamb&eacute;m a n&oacute;s Deus diz: &ldquo;N&atilde;o temas, eu estou contigo&rdquo;. Eu te fortale&ccedil;o, sustento e ajudo. Isto &eacute; Natal: raz&atilde;o do amor, do perd&atilde;o, da esperan&ccedil;a.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Vale lembrar que somos salvos por meio da bondade e do amor de Deus. Ele derramou o seu Esp&iacute;rito Santo sobre n&oacute;s por meio de Jesus Cristo, o menino nascido em Bel&eacute;m.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">E quando celebramos a vinda do Salvador, somos lembrados que ele &eacute; acolhido com todos os t&iacute;tulos atribu&iacute;dos a um governador: Conselheiro Maravilhoso, Deus Forte, Pai da Eternidade, Pr&iacute;ncipe da Paz (Isa&iacute;as 9.6). Por&eacute;m, ele &eacute; o oposto da maioria dos governantes que n&oacute;s conhecemos. Como escreve o pastor Geraldo Graf: &ldquo;Para aqueles que querem decidir sobre a vida dos outros, o amor de Cristo constrange e provoca. Para aqueles que incitam e praticam a viol&ecirc;ncia, a paz de Cristo incomoda.&rdquo;</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">A mensagem de Natal quer ser anunciada, testemunhada e vivenciada por todos n&oacute;s na sociedade rompida em que vivemos. Ela quer ser uma voz prof&eacute;tica, que anuncia transforma&ccedil;&atilde;o, neste sistema que n&atilde;o promove vida.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">O Salvador nasceu humilde em uma estrebaria e foi deitado numa manjedoura, esse &eacute; o fato que muda a hist&oacute;ria.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Que possamos nos deixar abra&ccedil;ar e fortalecer por Deus neste Natal.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\">Ao se preparar para celebrar o Natal, que cada um fa&ccedil;a do seu cora&ccedil;&atilde;o uma manjedoura.</p>\\r\\n<p class=\\\"wp-block-paragraph\\\"><strong>Assim como a estrela brilhou sobre a estrebaria em Bel&eacute;m, desejamos que a luz de Deus ilumine a sua vida.<br>Assim como os anjos anunciaram paz para a terra, desejamos que a paz de Deus preencha o seu cora&ccedil;&atilde;o.<br>Assim como os magos do oriente encontraram o caminho, desejamos que tamb&eacute;m voc&ecirc; possa andar nas trilhas de Deus.<br>Assim como Maria guardou as palavras dos anjos em seu cora&ccedil;&atilde;o, desejamos que a palavra de Deus permane&ccedil;a em voc&ecirc;, orientando a sua vida.<br>Assim como os pastores reconheceram o Salvador do mundo, desejamos que voc&ecirc; possa reconhecer a Jesus Cristo como seu Redentor.</strong></p>\\r\\n<p class=\\\"wp-block-paragraph\\\">&nbsp;</p>\\r\\n<p id=\\\"author\\\" class=\\\"wp-block-paragraph\\\"><strong>Pa. Ma. T&acirc;nia Cristina Weimer</strong><br><strong>Pastora Sinodal S&iacute;nodo Nordeste Ga&uacute;cho</strong></p>\\r\\n<div class=\\\"addtoany_share_save_container addtoany_content addtoany_content_bottom\\\">&nbsp;</div>\",\"imagem_capa\":null,\"imagem_capa_id\":15,\"status\":\"publicado\",\"status_anterior\":null,\"lixeira_em\":null,\"destaque\":0,\"comentarios_ativos\":0,\"publicado_em\":\"2023-01-01 00:00:00\",\"visualizacoes\":15,\"created_at\":\"2026-08-18 19:50:49\",\"updated_at\":\"2026-08-19 06:45:48\",\"seo_titulo\":null,\"seo_descricao\":null,\"seo_noindex\":0},\"tags\":[]}','2026-08-19 06:56:46');

DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_tags_nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `perfil_id` int(10) unsigned NOT NULL,
  `nome` varchar(150) NOT NULL,
  `email` varchar(190) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `ultimo_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_usuarios_perfil` (`perfil_id`),
  CONSTRAINT `fk_usuarios_perfil` FOREIGN KEY (`perfil_id`) REFERENCES `perfis` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `usuarios` (`id`,`perfil_id`,`nome`,`email`,`senha`,`ativo`,`ultimo_login`,`created_at`,`updated_at`) VALUES\n('1','1','Administrador','admin@ieclbparobe.com.br','$2y$12$6/olYzLKXxxN/DFyllIgmOe3nDXn/kmc5hTTVw59A4NVI94Vx.n.6','1','2026-08-19 06:20:12','2026-08-18 19:29:06','2026-08-19 06:20:12');

DROP TABLE IF EXISTS `widgets`;
CREATE TABLE `widgets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `area` varchar(40) NOT NULL DEFAULT 'home',
  `tipo` varchar(40) NOT NULL,
  `titulo` varchar(180) DEFAULT NULL,
  `conteudo` longtext DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `configuracao` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_widgets_area_ativo_ordem` (`area`,`ativo`,`ordem`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `widgets` (`id`,`area`,`tipo`,`titulo`,`conteudo`,`ativo`,`ordem`,`configuracao`,`created_at`,`updated_at`) VALUES\n('1','home','banners','','','1','10',NULL,'2026-08-18 20:30:46','2026-08-19 06:38:45'),
('2','home','apresentacao','','','1','20',NULL,'2026-08-18 20:30:46','2026-08-19 06:38:45'),
('3','home','destaque','','','1','30',NULL,'2026-08-18 20:30:46','2026-08-19 06:38:45'),
('4','home','agenda','Próximos cultos e eventos','','1','40',NULL,'2026-08-18 20:30:46','2026-08-19 06:38:58'),
('5','home','noticias','Últimas notícias','','1','50',NULL,'2026-08-18 20:30:46','2026-08-19 06:38:45'),
('6','home','galerias','Galerias de fotos','','1','60',NULL,'2026-08-18 20:30:46','2026-08-19 06:38:45'),
('7','home','comunidades','Nossas comunidades','','1','70',NULL,'2026-08-18 20:30:46','2026-08-19 06:38:45');
SET FOREIGN_KEY_CHECKS=1;
